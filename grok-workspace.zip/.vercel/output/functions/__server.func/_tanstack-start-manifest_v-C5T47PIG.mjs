//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C5T47PIG.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/browse",
			"/library",
			"/originals",
			"/schedule",
			"/anime/$id",
			"/watch/$kind/$id"
		],
		preloads: ["/assets/index-asXvpWUs.js", "/assets/anime-CbfrsAZo.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-asXvpWUs.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BS5WrRsc.js",
			"/assets/shell-CV_EfPho.js",
			"/assets/download-BDP2fTSw.js",
			"/assets/originals-C7Ib349u.js"
		]
	},
	"/browse": {
		filePath: "/workspace/src/routes/browse.tsx",
		children: void 0,
		preloads: ["/assets/browse-R-azBTs2.js", "/assets/shell-CV_EfPho.js"]
	},
	"/library": {
		filePath: "/workspace/src/routes/library.tsx",
		children: void 0,
		preloads: [
			"/assets/library-zqgOX9X0.js",
			"/assets/shell-CV_EfPho.js",
			"/assets/download-BDP2fTSw.js",
			"/assets/idb-zr311gXU.js"
		]
	},
	"/originals": {
		filePath: "/workspace/src/routes/originals.tsx",
		children: void 0,
		preloads: [
			"/assets/originals-AXe89cLr.js",
			"/assets/shell-CV_EfPho.js",
			"/assets/download-BDP2fTSw.js",
			"/assets/originals-C7Ib349u.js"
		]
	},
	"/schedule": {
		filePath: "/workspace/src/routes/schedule.tsx",
		children: void 0,
		preloads: ["/assets/schedule-bucf8dsA.js", "/assets/shell-CV_EfPho.js"]
	},
	"/anime/$id": {
		filePath: "/workspace/src/routes/anime.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/anime._id-C2JQe0Ku.js",
			"/assets/shell-CV_EfPho.js",
			"/assets/idb-zr311gXU.js",
			"/assets/anime._id-Dq5IATL1.js"
		]
	},
	"/watch/$kind/$id": {
		filePath: "/workspace/src/routes/watch.$kind.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/watch._kind._id-hpCLOn-x.js",
			"/assets/shell-CV_EfPho.js",
			"/assets/download-BDP2fTSw.js",
			"/assets/idb-zr311gXU.js",
			"/assets/originals-C7Ib349u.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
