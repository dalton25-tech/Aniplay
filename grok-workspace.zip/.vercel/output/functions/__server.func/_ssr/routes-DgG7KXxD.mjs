import { a as clock } from "./anime-NHBVMWMk.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Download, s as Play } from "../_libs/lucide-react.mjs";
import { a as TitleCard, c as useVaultReady, i as Shell, o as Warning, r as Rail, s as useVault, t as Hero } from "./shell-D1Gk60c_.mjs";
import { o as Route$6 } from "./router-D-VQKSYT.mjs";
import { n as lanternRun } from "./originals-Bs42ubAD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DgG7KXxD.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const data = Route$6.useLoaderData();
	const ready = useVaultReady();
	const progress = useVault((state) => state.progress);
	const continueItems = Object.values(progress).sort((a, b) => b.updated - a.updated).slice(0, 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		data.hero ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, { anime: data.hero }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalBillboard, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warning, { message: data.warning }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mt-10 overflow-hidden rounded-card border border-line bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: lanternRun.banner,
					alt: "",
					className: "h-full w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-accent uppercase",
							children: "Original reel · stream and download"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 font-display text-5xl text-fg",
							children: lanternRun.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: lanternRun.logline
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/watch/$kind/$id",
								params: {
									kind: "original",
									id: lanternRun.slug
								},
								search: { ep: 1 },
								className: "btn btn-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Play episode 1"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								className: "btn btn-ghost",
								href: lanternRun.episodes[0].src,
								download: "lantern-run-ep1.mp4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Download"]
							})]
						})
					]
				})]
			})
		}),
		ready && continueItems.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Continue",
			eyebrow: "Your seat",
			children: continueItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: item.href,
				className: "w-64",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-card border border-line bg-surface",
					children: [item.poster ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: item.poster,
						alt: "",
						className: "banner-frame w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "banner-frame bg-surface-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "line-clamp-1 text-sm text-fg",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: item.subtitle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 h-1 overflow-hidden rounded-full bg-line",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-accent",
									style: { width: `${item.duration ? Math.min(100, item.seconds / item.duration * 100) : 0}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: clock(item.seconds)
							})
						]
					})]
				})
			}, item.key))
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Lantern Run",
			eyebrow: "Playable now",
			children: lanternRun.episodes.map((episode) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/watch/$kind/$id",
				params: {
					kind: "original",
					id: lanternRun.slug
				},
				search: { ep: episode.number },
				className: "w-64",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-card border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: episode.still,
							alt: "",
							className: "banner-frame w-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-fg",
						children: [
							episode.number,
							". ",
							episode.title
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: episode.blurb
					})
				]
			}, episode.number))
		}),
		data.trending.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Trending",
			eyebrow: "Catalog",
			seeAll: true,
			children: data.trending.map((anime) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, { anime }, anime.id))
		}) : null,
		data.seasonal.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: data.seasonName,
			eyebrow: "Airing",
			seeAll: true,
			children: data.seasonal.map((anime) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, { anime }, anime.id))
		}) : null,
		data.popular.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Most watched",
			eyebrow: "All time",
			seeAll: true,
			children: data.popular.map((anime) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, { anime }, anime.id))
		}) : null
	] });
}
function OriginalBillboard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "hero overflow-hidden rounded-card border border-line",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: lanternRun.banner,
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/70 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 max-w-xl px-6 py-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-6xl text-fg",
					children: lanternRun.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-fg",
					children: lanternRun.logline
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
