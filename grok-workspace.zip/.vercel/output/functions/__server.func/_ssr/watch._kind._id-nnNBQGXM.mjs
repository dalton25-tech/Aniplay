import { i as __toESM } from "../_runtime.mjs";
import { a as clock } from "./anime-NHBVMWMk.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { c as Pause, d as Download, l as Maximize, n as Volume2, s as Play, t as VolumeX } from "../_libs/lucide-react.mjs";
import { c as useVaultReady, i as Shell, s as useVault } from "./shell-D1Gk60c_.mjs";
import { n as Route } from "./router-D-VQKSYT.mjs";
import { n as idbGet } from "./idb-C03qIfcn.mjs";
import { t as findOriginal } from "./originals-Bs42ubAD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/watch._kind._id-nnNBQGXM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CinemaPlayer({ src, poster, title, subtitle, progressKey, downloadName, startAt = 0, episodes }) {
	const videoRef = (0, import_react.useRef)(null);
	const stageRef = (0, import_react.useRef)(null);
	const setProgress = useVault((state) => state.setProgress);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [time, setTime] = (0, import_react.useState)(startAt);
	const [duration, setDuration] = (0, import_react.useState)(0);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [rate, setRate] = (0, import_react.useState)(1);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const applied = (0, import_react.useRef)("");
	(0, import_react.useEffect)(() => {
		const video = videoRef.current;
		if (!video) return;
		setFailed(false);
		const token = `${src}:${Math.floor(startAt)}`;
		const seek = () => {
			if (applied.current === token) return;
			const length = video.duration || 0;
			if (startAt > 1 && length > 0 && startAt < length - 1) {
				video.currentTime = startAt;
				applied.current = token;
			}
		};
		setDuration(video.duration || 0);
		seek();
		const onMeta = () => {
			setDuration(video.duration || 0);
			seek();
		};
		const onTime = () => setTime(video.currentTime || 0);
		const onPlay = () => setPlaying(true);
		const onPause = () => setPlaying(false);
		const onError = () => setFailed(true);
		video.addEventListener("loadedmetadata", onMeta);
		video.addEventListener("timeupdate", onTime);
		video.addEventListener("play", onPlay);
		video.addEventListener("pause", onPause);
		video.addEventListener("error", onError);
		return () => {
			video.removeEventListener("loadedmetadata", onMeta);
			video.removeEventListener("timeupdate", onTime);
			video.removeEventListener("play", onPlay);
			video.removeEventListener("pause", onPause);
			video.removeEventListener("error", onError);
		};
	}, [src, startAt]);
	(0, import_react.useEffect)(() => {
		const entry = {
			key: progressKey,
			title,
			subtitle,
			poster: poster ?? null,
			href: typeof window === "undefined" ? "" : `${window.location.pathname}${window.location.search}`,
			seconds: time,
			duration: duration || 0,
			updated: Date.now()
		};
		if (time < .5) return;
		const handle = window.setTimeout(() => setProgress(entry), 400);
		return () => window.clearTimeout(handle);
	}, [
		duration,
		poster,
		progressKey,
		setProgress,
		subtitle,
		time,
		title
	]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
			const video = videoRef.current;
			if (!video) return;
			if (event.key === " " || event.key === "k") {
				event.preventDefault();
				if (video.paused) video.play();
				else video.pause();
			} else if (event.key === "ArrowRight") video.currentTime = Math.min(video.duration || 0, video.currentTime + 5);
			else if (event.key === "ArrowLeft") video.currentTime = Math.max(0, video.currentTime - 5);
			else if (event.key === "f") toggleFullscreen();
			else if (event.key === "m") {
				video.muted = !video.muted;
				setMuted(video.muted);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const toggleFullscreen = () => {
		const stage = stageRef.current;
		if (!stage) return;
		if (document.fullscreenElement) document.exitFullscreen();
		else stage.requestFullscreen();
	};
	const togglePlay = () => {
		const video = videoRef.current;
		if (!video) return;
		if (video.paused) video.play();
		else video.pause();
	};
	const cycleRate = () => {
		const video = videoRef.current;
		if (!video) return;
		const next = rate === 1 ? 1.25 : rate === 1.25 ? 1.5 : rate === 1.5 ? 2 : 1;
		video.playbackRate = next;
		setRate(next);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "stage",
			ref: stageRef,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: videoRef,
					src,
					poster: poster ?? void 0,
					className: "banner-frame w-full bg-bg object-contain",
					playsInline: true,
					preload: "metadata",
					onClick: togglePlay
				}),
				failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "absolute inset-0 grid place-items-center bg-bg/80 px-6 text-center text-sm text-muted",
					children: "This reel could not be opened."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/80 to-transparent p-3 sm:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "scrub",
						type: "range",
						min: 0,
						max: duration || 0,
						step: .1,
						value: Math.min(time, duration || 0),
						"aria-label": "Seek",
						onChange: (event) => {
							const video = videoRef.current;
							if (!video) return;
							video.currentTime = Number(event.target.value);
						}
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-accent btn-icon",
								onClick: togglePlay,
								"aria-label": playing ? "Pause" : "Play",
								children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-xs text-fg",
								children: [
									clock(time),
									" / ",
									clock(duration)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: cycleRate,
								children: [rate, "×"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "btn btn-ghost btn-icon",
								"aria-label": muted ? "Unmute" : "Mute",
								onClick: () => {
									const video = videoRef.current;
									if (!video) return;
									video.muted = !video.muted;
									setMuted(video.muted);
								},
								children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-auto flex gap-2",
								children: [downloadName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									className: "btn btn-ghost",
									href: src,
									download: downloadName,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Download"]
								}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "btn btn-ghost btn-icon",
									"aria-label": "Fullscreen",
									onClick: toggleFullscreen,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize, { className: "size-4" })
								})]
							})
						]
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 flex flex-wrap items-end justify-between gap-3",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-accent uppercase",
				children: subtitle
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl text-fg",
				children: title
			})] })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: "Space plays and pauses. Arrows skip 5 seconds. F is fullscreen. M mutes."
		}),
		episodes && episodes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid gap-2 sm:grid-cols-3",
			children: episodes.map((episode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: episode.href,
				className: `rounded-card border px-3 py-3 text-sm ${episode.active ? "border-accent bg-surface text-fg" : "border-line bg-surface text-muted"}`,
				children: episode.label
			}, episode.href))
		}) : null
	] });
}
function WatchPage() {
	const { kind, id } = Route.useParams();
	const { ep } = Route.useSearch();
	const { anime } = Route.useLoaderData();
	if (kind === "original") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalWatch, {
		slug: id,
		episode: ep
	});
	if (kind === "shelf") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShelfWatch, {
		id,
		episode: ep
	});
	if (kind === "trailer") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrailerWatch, { anime });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-5xl",
		children: "That screening does not exist."
	}) });
}
function OriginalWatch({ slug, episode }) {
	const series = findOriginal(slug);
	const current = series?.episodes.find((item) => item.number === episode) ?? series?.episodes[0];
	const progress = useVault((state) => current ? state.progress[`original:${series?.slug}:${current.number}`] : void 0);
	if (!series || !current) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-5xl",
		children: "That reel is not on the program."
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CinemaPlayer, {
			src: current.src,
			poster: current.still,
			title: current.title,
			subtitle: `${series.title} · episode ${current.number}`,
			progressKey: `original:${series.slug}:${current.number}`,
			downloadName: `${series.slug}-ep${current.number}.mp4`,
			startAt: progress?.seconds ?? 0,
			episodes: series.episodes.map((item) => ({
				label: `${item.number}. ${item.title}`,
				href: `/watch/original/${series.slug}?ep=${item.number}`,
				active: item.number === current.number
			}))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 text-sm text-muted",
			children: current.blurb
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/originals",
			className: "mt-4 inline-block text-sm text-accent",
			children: "All Lantern Run reels"
		})
	] });
}
function TrailerWatch({ anime }) {
	const setProgress = useVault((state) => state.setProgress);
	(0, import_react.useEffect)(() => {
		if (!anime) return;
		setProgress({
			key: `trailer:${anime.id}`,
			title: anime.title,
			subtitle: "Official trailer",
			poster: anime.cover,
			href: `/watch/trailer/${anime.id}`,
			seconds: 1,
			duration: 1,
			updated: Date.now()
		});
	}, [anime, setProgress]);
	if (!anime || !anime.trailerId) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-5xl",
		children: "No official trailer is listed."
	}), anime ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/anime/$id",
		params: { id: String(anime.id) },
		className: "btn btn-ghost mt-4",
		children: ["Back to ", anime.title]
	}) : null] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-accent uppercase",
			children: "Official trailer"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl text-fg",
			children: anime.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stage mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				className: "banner-frame w-full",
				src: `https://www.youtube-nocookie.com/embed/${anime.trailerId}?rel=0&modestbranding=1`,
				title: `${anime.title} trailer`,
				allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share",
				allowFullScreen: true
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm text-muted",
			children: "This streams the official trailer. Daltron does not host full commercial episodes. Add a file you own on the title page to play it in the house player."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/anime/$id",
			params: { id: String(anime.id) },
			className: "btn btn-ghost mt-4",
			children: "Episode files"
		})
	] });
}
function ShelfWatch({ id, episode }) {
	const ready = useVaultReady();
	const shelf = useVault((state) => state.shelves.find((item) => item.id === id));
	const current = shelf?.episodes.find((item) => item.number === episode) ?? shelf?.episodes[0];
	const progress = useVault((state) => current ? state.progress[`shelf:${id}:${current.number}`] : void 0);
	const [src, setSrc] = (0, import_react.useState)(null);
	const [missing, setMissing] = (0, import_react.useState)(false);
	const urlRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!current) return;
		let cancelled = false;
		setSrc(null);
		setMissing(false);
		idbGet(`ep:${current.id}`).then((blob) => {
			if (cancelled) return;
			if (!blob) {
				setMissing(true);
				return;
			}
			const url = URL.createObjectURL(blob);
			urlRef.current = url;
			setSrc(url);
		});
		return () => {
			cancelled = true;
			if (urlRef.current) URL.revokeObjectURL(urlRef.current);
			urlRef.current = null;
		};
	}, [current?.id]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Opening your shelf…"
	}) });
	if (!shelf || !current) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-5xl",
		children: "That file is not on your shelf."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/library",
		className: "btn btn-ghost mt-4",
		children: "Library"
	})] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [missing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "The video file is missing from this browser."
	}) : null, src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CinemaPlayer, {
		src,
		poster: shelf.cover,
		title: shelf.title,
		subtitle: current.title,
		progressKey: `shelf:${shelf.id}:${current.number}`,
		downloadName: current.fileName,
		startAt: progress?.seconds ?? 0,
		episodes: shelf.episodes.map((item) => ({
			label: `${item.number}. ${item.fileName}`,
			href: `/watch/shelf/${shelf.id}?ep=${item.number}`,
			active: item.number === current.number
		}))
	}) : !missing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: "Loading the file from this device…"
	}) : null] });
}
//#endregion
export { WatchPage as component };
