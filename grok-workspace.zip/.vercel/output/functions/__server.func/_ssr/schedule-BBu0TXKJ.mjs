import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Shell, n as Poster, o as Warning } from "./shell-D1Gk60c_.mjs";
import { i as Route$2 } from "./router-D-VQKSYT.mjs";
import { t as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/schedule-BBu0TXKJ.js
var import_jsx_runtime = require_jsx_runtime();
function SchedulePage() {
	const data = Route$2.useLoaderData();
	const groups = /* @__PURE__ */ new Map();
	for (const item of data.items) {
		const key = format(/* @__PURE__ */ new Date(item.airingAt * 1e3), "EEEE, MMM d");
		const list = groups.get(key) ?? [];
		list.push(item);
		groups.set(key, list);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-accent uppercase",
			children: "Broadcast"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl text-fg",
			children: "Airing next"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-xl text-sm text-muted",
			children: "The next episode time for shows currently airing. Times follow this device."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warning, { message: data.warning }),
		[...groups.entries()].map(([day, items]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl text-fg",
				children: day
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-line rounded-card border border-line bg-surface",
				children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/anime/$id",
					params: { id: String(item.id) },
					className: "flex items-center gap-3 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-12 overflow-hidden rounded-md",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
								src: item.cover,
								title: item.title
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm text-fg",
								children: item.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: ["Episode ", item.episode]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-accent",
							children: format(/* @__PURE__ */ new Date(item.airingAt * 1e3), "h:mm a")
						})
					]
				}) }, item.id))
			})]
		}, day)),
		data.items.length === 0 && !data.warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 text-sm text-muted",
			children: "No upcoming episodes were listed."
		}) : null
	] });
}
//#endregion
export { SchedulePage as component };
