import { i as __toESM } from "../_runtime.mjs";
import { s as formatBytes, t as BROWSE_DEFAULT } from "./anime-NHBVMWMk.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Download, i as Trash2, s as Play } from "../_libs/lucide-react.mjs";
import { c as useVaultReady, i as Shell, n as Poster, s as useVault } from "./shell-D1Gk60c_.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as idbGet, r as idbPut, t as idbDel } from "./idb-C03qIfcn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/library-CHNlwlEb.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LibraryPage() {
	const ready = useVaultReady();
	const watchlist = useVault((state) => state.watchlist);
	const shelves = useVault((state) => state.shelves);
	const saveShelf = useVault((state) => state.saveShelf);
	const removeShelf = useVault((state) => state.removeShelf);
	const [hot, setHot] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const importFiles = async (files, shelfTitle) => {
		const videos = files.filter((file) => file.type.startsWith("video/") || /\.(mp4|webm|ogg|mkv|mov)$/i.test(file.name));
		if (videos.length === 0) {
			toast.error("Drop a video file.");
			return;
		}
		const shelf = {
			id: crypto.randomUUID(),
			title: shelfTitle.trim() || videos[0].name.replace(/\.[^.]+$/, ""),
			cover: null,
			anilistId: null,
			episodes: []
		};
		try {
			const episodes = [];
			for (let index = 0; index < videos.length; index += 1) {
				const file = videos[index];
				const episode = {
					id: crypto.randomUUID(),
					number: index + 1,
					title: `Episode ${index + 1}`,
					fileName: file.name,
					mime: file.type || "video/mp4",
					bytes: file.size
				};
				await idbPut(`ep:${episode.id}`, file);
				episodes.push(episode);
			}
			saveShelf({
				...shelf,
				episodes
			});
			setTitle("");
			toast.success("Saved on this device.");
		} catch {
			toast.error("This browser could not store that file.");
		}
	};
	const downloadEpisode = async (episode) => {
		const blob = await idbGet(`ep:${episode.id}`);
		if (!blob) {
			toast.error("That file is no longer on this device.");
			return;
		}
		const url = URL.createObjectURL(blob);
		const anchor = document.createElement("a");
		anchor.href = url;
		anchor.download = episode.fileName || `episode-${episode.number}.mp4`;
		anchor.click();
		window.setTimeout(() => URL.revokeObjectURL(url), 4e3);
	};
	const deleteShelf = async (shelf) => {
		await Promise.all(shelf.episodes.map((episode) => idbDel(`ep:${episode.id}`)));
		removeShelf(shelf.id);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-accent uppercase",
			children: "On this device"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl text-fg",
			children: "Library"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm text-muted",
			children: "Add videos you already own. Daltron plays them here and lets you download them back. They never leave this browser."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: `drop-zone mt-6 p-5 ${hot ? "is-hot" : ""}`,
			onDragOver: (event) => {
				event.preventDefault();
				setHot(true);
			},
			onDragLeave: () => setHot(false),
			onDrop: (event) => {
				event.preventDefault();
				setHot(false);
				importFiles(Array.from(event.dataTransfer.files), title);
			},
			onSubmit: (event) => {
				event.preventDefault();
				const input = event.currentTarget.elements.namedItem("files");
				if (input instanceof HTMLInputElement && input.files) {
					importFiles(Array.from(input.files), title);
					input.value = "";
				}
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
					className: "block text-sm text-muted",
					htmlFor: "shelf-title",
					children: "Shelf name"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "shelf-title",
					value: title,
					onChange: (event) => setTitle(event.target.value),
					placeholder: "Optional — otherwise the file name is used",
					className: "mt-2 h-11 w-full rounded-full border border-line bg-bg px-4 text-fg outline-none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "btn btn-accent mt-4",
					children: ["Choose videos", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						name: "files",
						type: "file",
						accept: "video/*",
						multiple: true,
						className: "sr-only",
						onChange: (event) => {
							if (event.target.files?.length) importFiles(Array.from(event.target.files), title);
							event.target.value = "";
						}
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "btn btn-ghost mt-4 ml-2",
					children: "Save to library"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs text-muted",
					children: "Or drop files on this panel."
				})
			]
		}),
		!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-6 text-sm text-muted",
			children: "Opening your shelf…"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl",
				children: "My list"
			}), watchlist.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					"Titles you bookmark show up here.",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/browse",
						search: BROWSE_DEFAULT,
						className: "text-fg",
						children: "Browse the catalog"
					}),
					"."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-6",
				children: watchlist.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/anime/$id",
					params: { id: String(item.id) },
					className: "w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-card border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
							src: item.cover,
							title: item.title
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 line-clamp-2 text-sm",
						children: item.title
					})]
				}, item.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl",
					children: "Shelves"
				}),
				shelves.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "No videos saved yet."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 space-y-4",
					children: shelves.map((shelf) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-card border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-display text-3xl text-fg",
								children: shelf.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [shelf.episodes.length, " files"]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "btn btn-ghost",
								onClick: () => void deleteShelf(shelf),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									"aria-hidden": "true"
								}), "Remove"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-3 divide-y divide-line",
							children: shelf.episodes.map((episode) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap items-center gap-2 py-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-8 text-sm text-muted",
										children: episode.number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 truncate text-sm",
										children: episode.fileName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: formatBytes(episode.bytes)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/watch/$kind/$id",
										params: {
											kind: "shelf",
											id: shelf.id
										},
										search: { ep: episode.number },
										className: "btn btn-accent",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "Play"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "btn btn-ghost",
										onClick: () => void downloadEpisode(episode),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Download"]
									})
								]
							}, episode.id))
						})]
					}, shelf.id))
				})
			]
		})
	] });
}
//#endregion
export { LibraryPage as component };
