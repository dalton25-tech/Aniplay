import { a as clock } from "./anime-NHBVMWMk.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { d as Download, s as Play } from "../_libs/lucide-react.mjs";
import { i as Shell } from "./shell-D1Gk60c_.mjs";
import { n as lanternRun } from "./originals-Bs42ubAD.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/originals-9iBJBpPZ.js
var import_jsx_runtime = require_jsx_runtime();
function OriginalsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "overflow-hidden rounded-card border border-line",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: lanternRun.banner,
				alt: "",
				className: "banner-frame w-full object-cover"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-6 text-xs tracking-widest text-accent uppercase",
			children: ["Daltron original · ", lanternRun.year]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-6xl text-fg",
			children: lanternRun.title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 max-w-2xl text-sm text-muted",
			children: lanternRun.logline
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-4",
			children: lanternRun.episodes.map((episode) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "grid gap-4 rounded-card border border-line bg-surface p-3 sm:grid-cols-[16rem_1fr] sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: episode.still,
					alt: "",
					className: "banner-frame w-full rounded-md object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-accent",
						children: [
							"Episode ",
							episode.number,
							" · ",
							clock(episode.seconds)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-3xl text-fg",
						children: episode.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: episode.blurb
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$kind/$id",
							params: {
								kind: "original",
								id: lanternRun.slug
							},
							search: { ep: episode.number },
							className: "btn btn-accent",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Play"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: "btn btn-ghost",
							href: episode.src,
							download: `lantern-run-ep${episode.number}.mp4`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Download"]
						})]
					})
				] })]
			}, episode.number))
		})
	] });
}
//#endregion
export { OriginalsPage as component };
