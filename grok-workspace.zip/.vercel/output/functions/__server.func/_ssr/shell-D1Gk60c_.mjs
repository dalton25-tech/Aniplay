import { i as __toESM } from "../_runtime.mjs";
import { l as metaLine, t as BROWSE_DEFAULT, u as scoreText } from "./anime-NHBVMWMk.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Link, p as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as DialogPortal, i as DialogOverlay, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as searchAnime } from "./catalog.functions-COUb6Pm0.mjs";
import { a as Star, f as Clapperboard, m as ChevronLeft, o as Search, p as ChevronRight, s as Play, u as Library } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-D1Gk60c_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Poster({ src, title, className = "" }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	if (!src || failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `poster-frame flex items-end bg-surface-2 p-3 ${className}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-2xl leading-none text-fg",
			children: title.slice(0, 1)
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		className: `poster-frame h-full w-full object-cover ${className}`,
		onError: () => setFailed(true)
	});
}
function TitleCard({ anime }) {
	const score = scoreText(anime.score);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/anime/$id",
		params: { id: String(anime.id) },
		className: "group w-36 sm:w-44",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-hidden rounded-card border border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
					src: anime.cover,
					title: anime.title,
					className: "transition duration-200 group-hover:scale-105"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 line-clamp-2 text-sm font-medium text-fg",
				children: anime.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-0.5 flex items-center gap-1 text-xs text-muted",
				children: [score ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
						className: "size-3 text-accent",
						"aria-hidden": "true"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: score }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" })
				] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: anime.formatLabel })]
			})
		]
	});
}
function Rail({ title, eyebrow, children, seeAll }) {
	const scroller = (0, import_react.useRef)(null);
	const move = (direction) => {
		scroller.current?.scrollBy({
			left: direction * 520,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-end justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [eyebrow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs tracking-widest text-accent uppercase",
				children: eyebrow
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl leading-none text-fg",
				children: title
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					seeAll ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/browse",
						search: BROWSE_DEFAULT,
						className: "text-sm text-muted hover:text-fg",
						children: "See all"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost btn-icon",
						"aria-label": "Scroll left",
						onClick: () => move(-1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-4" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "btn btn-ghost btn-icon",
						"aria-label": "Scroll right",
						onClick: () => move(1),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rail",
			ref: scroller,
			children
		})]
	});
}
function Hero({ anime }) {
	const score = scoreText(anime.score);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "hero overflow-hidden rounded-card border border-line",
		children: [
			anime.banner || anime.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: anime.banner || anime.cover || "",
				alt: "",
				className: "absolute inset-0 h-full w-full object-cover"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/80 to-bg/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 max-w-2xl px-5 py-8 sm:px-8 sm:py-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-accent uppercase",
						children: "Now in the house"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-5xl leading-none text-fg sm:text-7xl",
						children: anime.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: metaLine(anime)
					}),
					score ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 inline-flex items-center gap-1 text-sm text-fg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
								className: "size-4 text-accent",
								"aria-hidden": "true"
							}),
							score,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "/ 10"
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 line-clamp-3 max-w-xl text-sm text-fg/90 sm:text-base",
						children: anime.synopsis
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex flex-wrap gap-3",
						children: [anime.trailerId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$kind/$id",
							params: {
								kind: "trailer",
								id: String(anime.id)
							},
							search: { ep: 1 },
							className: "btn btn-accent",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Play trailer"]
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/anime/$id",
							params: { id: String(anime.id) },
							className: "btn btn-ghost",
							children: "Title page"
						})]
					})
				]
			})
		]
	});
}
function Warning({ message }) {
	if (!message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-4 rounded-card border border-line bg-surface px-4 py-3 text-sm text-muted",
		children: message
	});
}
var useUi = create((set) => ({
	searchOpen: false,
	setSearchOpen: (searchOpen) => set({ searchOpen })
}));
function SearchDialog() {
	const open = useUi((state) => state.searchOpen);
	const setOpen = useUi((state) => state.setSearchOpen);
	const [query, setQuery] = (0, import_react.useState)("");
	const [results, setResults] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) return;
		const trimmed = query.trim();
		if (trimmed.length < 2) {
			setResults([]);
			setBusy(false);
			return;
		}
		let cancelled = false;
		setBusy(true);
		const timer = window.setTimeout(() => {
			searchAnime({ data: { query: trimmed } }).then((items) => {
				if (!cancelled) setResults(items);
			}).catch(() => {
				if (!cancelled) setResults([]);
			}).finally(() => {
				if (!cancelled) setBusy(false);
			});
		}, 250);
		return () => {
			cancelled = true;
			window.clearTimeout(timer);
		};
	}, [open, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-40 bg-bg/80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "search-panel fixed top-24 left-1/2 z-50 -translate-x-1/2 rounded-card border border-line bg-surface p-4 shadow-none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-2xl text-fg",
					children: "Find a title"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "text-sm text-muted",
					children: "Search the AniList catalog. Press / anywhere."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-4 flex items-center gap-2 rounded-full border border-line bg-bg px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "size-4 text-muted",
						"aria-hidden": "true"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						autoFocus: true,
						value: query,
						onChange: (event) => setQuery(event.target.value),
						placeholder: "Title, romaji, or nickname",
						className: "h-11 w-full bg-transparent text-fg outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 max-h-96 space-y-2 overflow-y-auto",
					children: [
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Looking through the catalog…"
						}) : null,
						!busy && query.trim().length >= 2 && results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Nothing matches that."
						}) : null,
						results.map((anime) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/anime/$id",
							params: { id: String(anime.id) },
							onClick: () => setOpen(false),
							className: "flex items-center gap-3 rounded-card p-2 hover:bg-surface-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-12 overflow-hidden rounded-md",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
									src: anime.cover,
									title: anime.title
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-sm text-fg",
								children: anime.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [anime.formatLabel, scoreText(anime.score) ? ` · ${scoreText(anime.score)}` : ""]
							})] })]
						}, anime.id))
					]
				})
			]
		})] })
	});
}
var useVault = create()(persist((set, get) => ({
	watchlist: [],
	progress: {},
	shelves: [],
	toggleList: (entry) => {
		set({ watchlist: get().watchlist.some((item) => item.id === entry.id) ? get().watchlist.filter((item) => item.id !== entry.id) : [entry, ...get().watchlist] });
	},
	setProgress: (entry) => set({ progress: {
		...get().progress,
		[entry.key]: entry
	} }),
	saveShelf: (shelf) => {
		const shelves = get().shelves;
		const index = shelves.findIndex((item) => item.id === shelf.id);
		if (index === -1) {
			set({ shelves: [shelf, ...shelves] });
			return;
		}
		const next = shelves.slice();
		next[index] = shelf;
		set({ shelves: next });
	},
	removeShelf: (id) => set({
		shelves: get().shelves.filter((item) => item.id !== id),
		progress: Object.fromEntries(Object.entries(get().progress).filter(([, entry]) => !entry.href.includes(`/watch/shelf/${id}`)))
	})
}), {
	name: "daltron-aniverse",
	skipHydration: true
}));
function useVaultReady() {
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		useVault.persist.rehydrate();
		const unsub = useVault.persist.onFinishHydration(() => setReady(true));
		if (useVault.persist.hasHydrated()) setReady(true);
		return unsub;
	}, []);
	return ready;
}
var LINKS = [
	{
		to: "/",
		label: "Home",
		search: void 0
	},
	{
		to: "/browse",
		label: "Browse",
		search: BROWSE_DEFAULT
	},
	{
		to: "/schedule",
		label: "Schedule",
		search: void 0
	},
	{
		to: "/originals",
		label: "Originals",
		search: void 0
	},
	{
		to: "/library",
		label: "Library",
		search: void 0
	}
];
function Shell({ children }) {
	useVaultReady();
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const setSearchOpen = useUi((state) => state.setSearchOpen);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
			if (event.key === "/" && !typing) {
				event.preventDefault();
				setSearchOpen(true);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [setSearchOpen]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "#content",
				className: "sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-surface focus:px-3 focus:py-2",
				children: "Skip to content"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/",
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-9 place-items-center rounded-full border border-accent text-sm text-accent",
								children: "灯"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "leading-none",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs tracking-widest text-muted",
									children: "DALTRON"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-xl italic text-fg",
									children: "Aniverse"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "ml-2 hidden items-center gap-1 md:flex",
							children: LINKS.map((link) => {
								const active = link.to === "/" ? pathname === "/" : pathname.startsWith(link.to);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: link.to,
									search: link.search,
									className: `rounded-full px-3 py-2 text-sm ${active ? "bg-surface text-fg" : "text-muted hover:text-fg"}`,
									children: link.label
								}, link.to);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost ml-auto",
							onClick: () => setSearchOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Search"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex gap-1 overflow-x-auto px-4 pb-3 md:hidden",
					children: LINKS.map((link) => {
						const active = link.to === "/" ? pathname === "/" : pathname.startsWith(link.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: link.to,
							search: link.search,
							className: `shrink-0 rounded-full px-3 py-2 text-sm ${active ? "bg-surface text-fg" : "text-muted"}`,
							children: link.label
						}, link.to);
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				id: "content",
				className: "mx-auto max-w-6xl px-4 py-6",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
				className: "mx-auto mt-8 max-w-6xl border-t border-line px-4 py-8 text-sm text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-fg",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clapperboard, {
							className: "size-4 text-accent",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-2xl italic",
							children: "Daltron Aniverse"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl",
						children: "A local-first anime house. Catalog and cover art come from AniList. Official trailers stream from their YouTube uploads. Lantern Run is an original reel you can play or download. Videos you add stay in this browser — nothing is uploaded."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, {
							className: "size-4",
							"aria-hidden": "true"
						}), "Your shelf lives on this device."]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchDialog, {})
		]
	});
}
//#endregion
export { TitleCard as a, useVaultReady as c, Shell as i, Poster as n, Warning as o, Rail as r, useVault as s, Hero as t };
