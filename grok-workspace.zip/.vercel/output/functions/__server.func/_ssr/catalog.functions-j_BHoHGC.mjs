import { c as formatLabel, d as seasonLabel, f as statusLabel, o as currentSeason } from "./anime-NHBVMWMk.mjs";
import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog.functions-j_BHoHGC.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ENDPOINT = "https://graphql.anilist.co";
var TTL = 3e5;
var memory = /* @__PURE__ */ new Map();
var CARD_FIELDS = `
  id
  title { romaji english native }
  description(asHtml: false)
  coverImage { extraLarge large }
  bannerImage
  episodes
  duration
  status
  season
  seasonYear
  format
  averageScore
  genres
  studios(isMain: true) { nodes { name } }
  trailer { id site }
  nextAiringEpisode { episode airingAt }
`;
function cleanSynopsis(value, max) {
	if (!value) return "";
	const text = value.replace(/<br\s*\/?>/gi, " ").replace(/<[^>]+>/g, "").replace(/"/g, "\"").replace(/&#039;/g, "'").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/\s*\(Source:[\s\S]*$/i, "").replace(/\s+/g, " ").trim();
	if (text.length <= max) return text;
	return `${text.slice(0, max - 1).trimEnd()}…`;
}
function mapCard(raw, synopsisMax = 280) {
	const romaji = raw.title?.romaji?.trim() || "Untitled";
	const english = raw.title?.english?.trim();
	const next = raw.nextAiringEpisode;
	const trailerSite = raw.trailer?.site?.toLowerCase();
	return {
		id: raw.id,
		title: english || romaji,
		romaji,
		native: raw.title?.native ?? null,
		synopsis: cleanSynopsis(raw.description, synopsisMax),
		cover: raw.coverImage?.extraLarge || raw.coverImage?.large || null,
		banner: raw.bannerImage ?? null,
		episodes: raw.episodes ?? null,
		duration: raw.duration ?? null,
		status: raw.status ?? "",
		statusLabel: statusLabel(raw.status),
		seasonLabel: seasonLabel(raw.season, raw.seasonYear),
		format: raw.format ?? "",
		formatLabel: formatLabel(raw.format),
		score: raw.averageScore ?? null,
		genres: raw.genres ?? [],
		studios: (raw.studios?.nodes ?? []).map((node) => node.name).filter((name) => Boolean(name)),
		trailerId: trailerSite === "youtube" && raw.trailer?.id ? raw.trailer.id : null,
		nextEpisode: next?.episode && next.airingAt ? {
			episode: next.episode,
			airingAt: next.airingAt
		} : null
	};
}
async function gql(query, variables) {
	const response = await fetch(ENDPOINT, {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Accept: "application/json"
		},
		body: JSON.stringify({
			query,
			variables
		}),
		signal: AbortSignal.timeout(12e3)
	});
	if (!response.ok) throw new Error(`Catalog is unavailable (${response.status}).`);
	const json = await response.json();
	if (json.errors?.length) throw new Error(json.errors[0]?.message || "Catalog request failed.");
	if (!json.data) throw new Error("Catalog returned nothing.");
	return json.data;
}
async function cached(key, load) {
	const hit = memory.get(key);
	if (hit && Date.now() - hit.at < TTL) return hit.value;
	const value = await load();
	memory.set(key, {
		at: Date.now(),
		value
	});
	return value;
}
var getHome_createServerFn_handler = createServerRpc({
	id: "76e2261559e54c80a492b4a527d1a4de758e4665b4feec2e685f000522078484",
	name: "getHome",
	filename: "src/lib/catalog.functions.ts"
}, (opts) => getHome.__executeServer(opts));
var getHome = createServerFn({ method: "GET" }).handler(getHome_createServerFn_handler, async () => {
	const { season, year } = currentSeason();
	try {
		const data = await cached(`home:${season}:${year}`, () => gql(`query ($season: MediaSeason, $year: Int) {
          trending: Page(page: 1, perPage: 16) {
            media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
          seasonal: Page(page: 1, perPage: 16) {
            media(type: ANIME, season: $season, seasonYear: $year, sort: POPULARITY_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
          popular: Page(page: 1, perPage: 16) {
            media(type: ANIME, sort: POPULARITY_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
        }`, {
			season,
			year
		}));
		const trending = data.trending.media.map((item) => mapCard(item));
		const seasonal = data.seasonal.media.map((item) => mapCard(item));
		const popular = data.popular.media.map((item) => mapCard(item));
		return {
			hero: trending.find((item) => item.banner && item.synopsis) ?? trending[0] ?? null,
			trending,
			seasonal,
			seasonName: seasonLabel(season, year) ?? "This season",
			popular,
			warning: null
		};
	} catch (error) {
		return {
			hero: null,
			trending: [],
			seasonal: [],
			seasonName: seasonLabel(season, year) ?? "This season",
			popular: [],
			warning: error instanceof Error ? error.message : "Catalog is unavailable."
		};
	}
});
var getAnime_createServerFn_handler = createServerRpc({
	id: "e5762000e123e9893413e9829e2b5d19ef7bfbbe48d41a77640a03bda420456f",
	name: "getAnime",
	filename: "src/lib/catalog.functions.ts"
}, (opts) => getAnime.__executeServer(opts));
var getAnime = createServerFn({ method: "GET" }).validator((input) => {
	const id = Number(input?.id);
	if (!Number.isFinite(id) || id <= 0) throw new Error("That title is missing.");
	return { id };
}).handler(getAnime_createServerFn_handler, async ({ data }) => {
	try {
		return await cached(`anime:${data.id}`, async () => {
			const result = await gql(`query ($id: Int) {
            Media(id: $id, type: ANIME, isAdult: false) {
              ${CARD_FIELDS}
              relations {
                edges {
                  relationType
                  node { id title { romaji english } coverImage { large } format type }
                }
              }
            }
          }`, { id: data.id });
			if (!result.Media) return null;
			const card = mapCard(result.Media, 900);
			const related = (result.Media.relations?.edges ?? []).filter((edge) => edge.node && edge.node.type !== "MANGA").slice(0, 12).map((edge) => {
				const node = edge.node;
				const romaji = node.title?.romaji?.trim() || "Untitled";
				return {
					id: node.id,
					title: node.title?.english?.trim() || romaji,
					cover: node.coverImage?.large || node.coverImage?.extraLarge || null,
					formatLabel: formatLabel(node.format),
					relation: (edge.relationType ?? "Related").replaceAll("_", " ").toLowerCase()
				};
			});
			return {
				...card,
				related
			};
		});
	} catch {
		return null;
	}
});
var SORTS = /* @__PURE__ */ new Set([
	"TRENDING_DESC",
	"POPULARITY_DESC",
	"SCORE_DESC",
	"START_DATE_DESC"
]);
var FORMATS = /* @__PURE__ */ new Set([
	"",
	"TV",
	"MOVIE",
	"OVA",
	"ONA",
	"SPECIAL"
]);
var browseAnime_createServerFn_handler = createServerRpc({
	id: "32393998d96dce186c9f76c58c2b8814d13181a443122f0a8e25146bede83517",
	name: "browseAnime",
	filename: "src/lib/catalog.functions.ts"
}, (opts) => browseAnime.__executeServer(opts));
var browseAnime = createServerFn({ method: "GET" }).validator((input) => {
	const page = Math.min(20, Math.max(1, Number(input?.page) || 1));
	const sort = SORTS.has(input?.sort) ? input.sort : "TRENDING_DESC";
	const format = FORMATS.has(input?.format) ? input.format : "";
	return {
		genre: typeof input?.genre === "string" ? input.genre.slice(0, 40) : "",
		format,
		sort,
		page
	};
}).handler(browseAnime_createServerFn_handler, async ({ data }) => {
	try {
		const payload = await cached(`browse:${JSON.stringify(data)}`, () => gql(`query ($page: Int, $sort: [MediaSort], $genre: String, $format: MediaFormat) {
            Page(page: $page, perPage: 24) {
              pageInfo { hasNextPage }
              media(type: ANIME, sort: $sort, genre: $genre, format: $format, isAdult: false) { ${CARD_FIELDS} }
            }
          }`, {
			page: data.page,
			sort: [data.sort],
			genre: data.genre || void 0,
			format: data.format || void 0
		}));
		return {
			items: payload.Page.media.map((item) => mapCard(item, 140)),
			page: data.page,
			hasNext: payload.Page.pageInfo.hasNextPage,
			warning: null
		};
	} catch (error) {
		return {
			items: [],
			page: data.page,
			hasNext: false,
			warning: error instanceof Error ? error.message : "Catalog is unavailable."
		};
	}
});
var searchAnime_createServerFn_handler = createServerRpc({
	id: "32c770bdefc9edf8e661160619cb0c20fb13a3f6d0fdf7f6fb0e9502ec665575",
	name: "searchAnime",
	filename: "src/lib/catalog.functions.ts"
}, (opts) => searchAnime.__executeServer(opts));
var searchAnime = createServerFn({ method: "GET" }).validator((input) => {
	return { query: (input?.query ?? "").trim().slice(0, 80) };
}).handler(searchAnime_createServerFn_handler, async ({ data }) => {
	if (data.query.length < 2) return [];
	try {
		return (await cached(`search:${data.query.toLowerCase()}`, () => gql(`query ($search: String) {
            Page(page: 1, perPage: 8) {
              media(type: ANIME, search: $search, sort: SEARCH_MATCH, isAdult: false) { ${CARD_FIELDS} }
            }
          }`, { search: data.query }))).Page.media.map((item) => mapCard(item, 120));
	} catch {
		return [];
	}
});
var getSchedule_createServerFn_handler = createServerRpc({
	id: "e05f4b86135e573d92a789fc4645fb01147698c6ba4ca30458f6fe4159da32ac",
	name: "getSchedule",
	filename: "src/lib/catalog.functions.ts"
}, (opts) => getSchedule.__executeServer(opts));
var getSchedule = createServerFn({ method: "GET" }).handler(getSchedule_createServerFn_handler, async () => {
	try {
		return {
			items: (await cached("schedule", () => gql(`query {
          Page(page: 1, perPage: 40) {
            media(type: ANIME, status: RELEASING, sort: POPULARITY_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
        }`, {}))).Page.media.map((item) => mapCard(item, 80)).filter((item) => Boolean(item.nextEpisode)).map((item) => ({
				...item,
				airingAt: item.nextEpisode.airingAt,
				episode: item.nextEpisode.episode
			})).sort((a, b) => a.airingAt - b.airingAt),
			warning: null
		};
	} catch (error) {
		return {
			items: [],
			warning: error instanceof Error ? error.message : "Schedule is unavailable."
		};
	}
});
//#endregion
export { browseAnime_createServerFn_handler, getAnime_createServerFn_handler, getHome_createServerFn_handler, getSchedule_createServerFn_handler, searchAnime_createServerFn_handler };
