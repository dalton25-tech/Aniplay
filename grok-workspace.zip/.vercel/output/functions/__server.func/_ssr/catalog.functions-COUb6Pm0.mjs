import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog.functions-COUb6Pm0.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getHome = createServerFn({ method: "GET" }).handler(createSsrRpc("76e2261559e54c80a492b4a527d1a4de758e4665b4feec2e685f000522078484"));
var getAnime = createServerFn({ method: "GET" }).validator((input) => {
	const id = Number(input?.id);
	if (!Number.isFinite(id) || id <= 0) throw new Error("That title is missing.");
	return { id };
}).handler(createSsrRpc("e5762000e123e9893413e9829e2b5d19ef7bfbbe48d41a77640a03bda420456f"));
var SORTS = /* @__PURE__ */ new Set([
	"TRENDING_DESC",
	"POPULARITY_DESC",
	"SCORE_DESC",
	"START_DATE_DESC"
]);
var FORMATS = /* @__PURE__ */ new Set([
	"",
	"TV",
	"MOVIE",
	"OVA",
	"ONA",
	"SPECIAL"
]);
var browseAnime = createServerFn({ method: "GET" }).validator((input) => {
	const page = Math.min(20, Math.max(1, Number(input?.page) || 1));
	const sort = SORTS.has(input?.sort) ? input.sort : "TRENDING_DESC";
	const format = FORMATS.has(input?.format) ? input.format : "";
	return {
		genre: typeof input?.genre === "string" ? input.genre.slice(0, 40) : "",
		format,
		sort,
		page
	};
}).handler(createSsrRpc("32393998d96dce186c9f76c58c2b8814d13181a443122f0a8e25146bede83517"));
var searchAnime = createServerFn({ method: "GET" }).validator((input) => {
	return { query: (input?.query ?? "").trim().slice(0, 80) };
}).handler(createSsrRpc("32c770bdefc9edf8e661160619cb0c20fb13a3f6d0fdf7f6fb0e9502ec665575"));
var getSchedule = createServerFn({ method: "GET" }).handler(createSsrRpc("e05f4b86135e573d92a789fc4645fb01147698c6ba4ca30458f6fe4159da32ac"));
//#endregion
export { searchAnime as a, getSchedule as i, getAnime as n, getHome as r, browseAnime as t };
