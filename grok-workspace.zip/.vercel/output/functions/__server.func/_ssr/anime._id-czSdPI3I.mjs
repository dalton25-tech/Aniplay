import { l as metaLine, t as BROWSE_DEFAULT, u as scoreText } from "./anime-NHBVMWMk.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { g as BookmarkCheck, h as Bookmark, s as Play } from "../_libs/lucide-react.mjs";
import { c as useVaultReady, i as Shell, n as Poster, o as Warning, r as Rail, s as useVault } from "./shell-D1Gk60c_.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as Route$1 } from "./router-D-VQKSYT.mjs";
import { r as idbPut, t as idbDel } from "./idb-C03qIfcn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/anime._id-czSdPI3I.js
var import_jsx_runtime = require_jsx_runtime();
function AnimePage() {
	const { anime } = Route$1.useLoaderData();
	const ready = useVaultReady();
	const watchlist = useVault((state) => state.watchlist);
	const shelves = useVault((state) => state.shelves);
	const toggleList = useVault((state) => state.toggleList);
	const saveShelf = useVault((state) => state.saveShelf);
	const listed = watchlist.some((item) => item.id === anime.id);
	const shelf = shelves.find((item) => item.anilistId === anime.id) ?? null;
	const slotCount = Math.min(anime.episodes ?? 12, 24);
	const score = scoreText(anime.score);
	const ensureShelf = () => {
		if (shelf) return shelf;
		const created = {
			id: crypto.randomUUID(),
			title: anime.title,
			cover: anime.cover,
			anilistId: anime.id,
			episodes: []
		};
		saveShelf(created);
		return created;
	};
	const attach = async (number, file) => {
		if (!file) return;
		const current = ensureShelf();
		const previous = current.episodes.find((episode) => episode.number === number);
		const episode = {
			id: crypto.randomUUID(),
			number,
			title: `Episode ${number}`,
			fileName: file.name,
			mime: file.type || "video/mp4",
			bytes: file.size
		};
		try {
			await idbPut(`ep:${episode.id}`, file);
			if (previous) await idbDel(`ep:${previous.id}`);
			saveShelf({
				...current,
				episodes: [...current.episodes.filter((item) => item.number !== number), episode].sort((a, b) => a.number - b.number)
			});
			toast.success(`Episode ${number} is on this device.`);
		} catch {
			toast.error("This browser could not store that file.");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "overflow-hidden rounded-card border border-line",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [anime.banner ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: anime.banner,
					alt: "",
					className: "h-64 w-full object-cover sm:h-80"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 bg-surface" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg to-transparent" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 px-4 pb-6 sm:grid-cols-[11rem_1fr] sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "-mt-16 w-40 overflow-hidden rounded-card border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
						src: anime.cover,
						title: anime.title
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tracking-widest text-accent uppercase",
						children: metaLine(anime)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-5xl leading-none text-fg",
						children: anime.title
					}),
					anime.native ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: anime.native
					}) : null,
					score ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-fg",
						children: [score, " / 10"]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-sm text-muted",
						children: anime.synopsis || "No synopsis yet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: anime.genres.map((genre) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/browse",
							search: {
								...BROWSE_DEFAULT,
								genre
							},
							className: "rounded-full border border-line px-3 py-1 text-xs text-muted",
							children: genre
						}, genre))
					}),
					anime.studios.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: anime.studios.join(" · ")
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex flex-wrap gap-2",
						children: [anime.trailerId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/watch/$kind/$id",
							params: {
								kind: "trailer",
								id: String(anime.id)
							},
							search: { ep: 1 },
							className: "btn btn-accent",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
								className: "size-4",
								"aria-hidden": "true"
							}), "Play trailer"]
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "btn btn-ghost",
							onClick: () => toggleList({
								id: anime.id,
								title: anime.title,
								cover: anime.cover
							}),
							children: [listed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" }), listed ? "On my list" : "My list"]
						})]
					})
				] })]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-4xl text-fg",
					children: "Episodes"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted",
					children: "Trailers play from the official upload. Full episodes are not hosted here. Add a video file you already have the right to watch — it stays in this browser, then you can stream it and download it again."
				}),
				!ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: "Opening your shelf…"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 grid gap-2",
					children: Array.from({ length: slotCount }, (_, index) => {
						const number = index + 1;
						const episode = shelf?.episodes.find((item) => item.number === number);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-3 rounded-card border border-line bg-surface px-3 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-10 text-sm text-muted",
									children: number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 text-sm text-fg",
									children: episode ? episode.fileName : `Episode ${number}`
								}),
								episode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/watch/$kind/$id",
									params: {
										kind: "shelf",
										id: shelf?.id ?? ""
									},
									search: { ep: number },
									className: "btn btn-accent",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {
										className: "size-4",
										"aria-hidden": "true"
									}), "Play"]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "btn btn-ghost",
									children: [episode ? "Replace" : "Add file", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "video/*",
										className: "sr-only",
										onChange: (event) => {
											const file = event.target.files?.[0];
											attach(number, file);
											event.target.value = "";
										}
									})]
								})
							]
						}, number);
					})
				}),
				anime.episodes && anime.episodes > slotCount ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs text-muted",
					children: [
						"Showing the first ",
						slotCount,
						" episodes. Add more from your library."
					]
				}) : null
			]
		}),
		anime.related.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rail, {
			title: "Related",
			children: anime.related.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/anime/$id",
				params: { id: String(item.id) },
				className: "w-36 sm:w-44",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-card border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Poster, {
							src: item.cover,
							title: item.title
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 line-clamp-2 text-sm text-fg",
						children: item.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted capitalize",
						children: item.relation
					})
				]
			}, `${item.relation}-${item.id}`))
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warning, { message: null })
	] });
}
//#endregion
export { AnimePage as component };
