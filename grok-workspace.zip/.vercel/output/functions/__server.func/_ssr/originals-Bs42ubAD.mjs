//#region node_modules/.nitro/vite/services/ssr/assets/originals-Bs42ubAD.js
var lanternRun = {
	slug: "lantern-run",
	title: "Lantern Run",
	logline: "An original motion reel made for Daltron. A courier, a paper lantern, and a city that does not exist anywhere else. Stream it here or save the file.",
	poster: "/originals/poster.jpg",
	banner: "/originals/banner.jpg",
	year: 2026,
	genres: [
		"Original",
		"Action",
		"Night"
	],
	episodes: [
		{
			number: 1,
			title: "Rooftop Relay",
			blurb: "A courier crosses the roofs with one light and a long red scarf.",
			src: "/originals/ep1.mp4",
			still: "/originals/ep1.jpg",
			seconds: 15
		},
		{
			number: 2,
			title: "Paper Bridge",
			blurb: "Two lanterns stop over black water.",
			src: "/originals/ep2.mp4",
			still: "/originals/ep2.jpg",
			seconds: 15
		},
		{
			number: 3,
			title: "Crane Market",
			blurb: "A paper crane folded out of metal sweeps the night market.",
			src: "/originals/ep3.mp4",
			still: "/originals/ep3.jpg",
			seconds: 15
		}
	]
};
function findOriginal(slug) {
	return slug === lanternRun.slug ? lanternRun : null;
}
//#endregion
export { lanternRun as n, findOriginal as t };
