import { t as BROWSE_DEFAULT } from "./anime-NHBVMWMk.mjs";
import { b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { i as Shell } from "./shell-D1Gk60c_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/anime._id-B-m_q69u.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
	className: "font-display text-5xl",
	children: "That title is not in the catalog."
}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
	to: "/browse",
	search: BROWSE_DEFAULT,
	className: "btn btn-accent mt-4",
	children: "Browse"
})] });
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
