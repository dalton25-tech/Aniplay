//#region node_modules/.nitro/vite/services/ssr/assets/anime-NHBVMWMk.js
var BROWSE_DEFAULT = {
	genre: "",
	format: "",
	sort: "TRENDING_DESC",
	page: 1
};
var GENRES = [
	"Action",
	"Adventure",
	"Comedy",
	"Drama",
	"Fantasy",
	"Horror",
	"Mystery",
	"Romance",
	"Sci-Fi",
	"Slice of Life",
	"Sports",
	"Supernatural",
	"Thriller"
];
var FORMATS = [
	{
		id: "TV",
		label: "Series"
	},
	{
		id: "MOVIE",
		label: "Movies"
	},
	{
		id: "OVA",
		label: "OVA"
	},
	{
		id: "ONA",
		label: "ONA"
	},
	{
		id: "SPECIAL",
		label: "Specials"
	}
];
var SORTS = [
	{
		id: "TRENDING_DESC",
		label: "Trending"
	},
	{
		id: "POPULARITY_DESC",
		label: "Popular"
	},
	{
		id: "SCORE_DESC",
		label: "Top rated"
	},
	{
		id: "START_DATE_DESC",
		label: "Newest"
	}
];
var FORMAT_LABELS = {
	TV: "Series",
	TV_SHORT: "Short",
	MOVIE: "Movie",
	SPECIAL: "Special",
	OVA: "OVA",
	ONA: "ONA",
	MUSIC: "Music"
};
var STATUS_LABELS = {
	FINISHED: "Completed",
	RELEASING: "Airing",
	NOT_YET_RELEASED: "Upcoming",
	CANCELLED: "Cancelled",
	HIATUS: "Hiatus"
};
function formatLabel(format) {
	if (!format) return "Anime";
	return FORMAT_LABELS[format] ?? format;
}
function statusLabel(status) {
	if (!status) return "Unknown";
	return STATUS_LABELS[status] ?? status;
}
function seasonLabel(season, year) {
	if (!season && !year) return null;
	const name = season ? season.charAt(0) + season.slice(1).toLowerCase() : "Season";
	return year ? `${name} ${year}` : name;
}
function scoreText(score) {
	if (score == null) return null;
	return (score / 10).toFixed(1);
}
function metaLine(anime) {
	return [
		anime.formatLabel,
		anime.seasonLabel,
		anime.episodes ? `${anime.episodes} eps` : null,
		anime.duration ? `${anime.duration} min` : null,
		anime.statusLabel
	].filter(Boolean).join("  ·  ");
}
function currentSeason(date = /* @__PURE__ */ new Date()) {
	const month = date.getUTCMonth();
	const year = date.getUTCFullYear();
	if (month <= 2) return {
		season: "WINTER",
		year
	};
	if (month <= 5) return {
		season: "SPRING",
		year
	};
	if (month <= 8) return {
		season: "SUMMER",
		year
	};
	return {
		season: "FALL",
		year
	};
}
function clock(seconds) {
	if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
	const total = Math.floor(seconds);
	return `${Math.floor(total / 60)}:${(total % 60).toString().padStart(2, "0")}`;
}
function formatBytes(bytes) {
	if (bytes < 1048576) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
//#endregion
export { clock as a, formatLabel as c, seasonLabel as d, statusLabel as f, SORTS as i, metaLine as l, FORMATS as n, currentSeason as o, GENRES as r, formatBytes as s, BROWSE_DEFAULT as t, scoreText as u };
