import { i as SORTS, n as FORMATS, r as GENRES } from "./anime-NHBVMWMk.mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as TitleCard, i as Shell, o as Warning } from "./shell-D1Gk60c_.mjs";
import { a as Route$5 } from "./router-D-VQKSYT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/browse-UJvW1wNE.js
var import_jsx_runtime = require_jsx_runtime();
function BrowsePage() {
	const search = Route$5.useSearch();
	const data = Route$5.useLoaderData();
	const navigate = useNavigate();
	const setSearch = (patch) => {
		navigate({
			to: "/browse",
			search: {
				...search,
				...patch,
				page: patch.page ?? 1
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-widest text-accent uppercase",
			children: "Catalog"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-5xl text-fg",
			children: "Browse"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex gap-2 overflow-x-auto pb-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				active: search.genre === "",
				onClick: () => setSearch({ genre: "" }),
				children: "All genres"
			}), GENRES.map((genre) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
				active: search.genre === genre,
				onClick: () => setSearch({ genre }),
				children: genre
			}, genre))]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-2 flex flex-wrap gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: search.format === "",
					onClick: () => setSearch({ format: "" }),
					children: "Any format"
				}),
				FORMATS.map((format) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
					active: search.format === format.id,
					onClick: () => setSearch({ format: format.id }),
					children: format.label
				}, format.id)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "ml-auto flex items-center gap-2 text-sm text-muted",
					children: ["Sort", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						className: "h-11 rounded-full border border-line bg-surface px-3 text-fg",
						value: search.sort,
						onChange: (event) => setSearch({ sort: event.target.value }),
						children: SORTS.map((sort) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: sort.id,
							children: sort.label
						}, sort.id))
					})]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Warning, { message: data.warning }),
		data.items.length === 0 && !data.warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-8 text-sm text-muted",
			children: "Nothing in this cut. Try another genre."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6",
			children: data.items.map((anime) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TitleCard, { anime }, anime.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 flex items-center justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					disabled: search.page <= 1,
					onClick: () => setSearch({ page: search.page - 1 }),
					children: "Previous"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm text-muted",
					children: ["Page ", data.page]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "btn btn-ghost",
					disabled: !data.hasNext,
					onClick: () => setSearch({ page: search.page + 1 }),
					children: "Next"
				})
			]
		})
	] });
}
function FilterChip({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: `btn shrink-0 ${active ? "btn-accent" : "btn-ghost"}`,
		children
	});
}
//#endregion
export { BrowsePage as component };
