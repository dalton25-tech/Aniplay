//#region node_modules/.nitro/vite/services/ssr/assets/idb-C03qIfcn.js
var DB_NAME = "daltron-aniverse";
var STORE = "files";
function openDb() {
	return new Promise((resolve, reject) => {
		const request = indexedDB.open(DB_NAME, 1);
		request.onupgradeneeded = () => {
			const db = request.result;
			if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
		};
		request.onsuccess = () => resolve(request.result);
		request.onerror = () => reject(request.error ?? /* @__PURE__ */ new Error("Could not open the local shelf."));
	});
}
function run(mode, work) {
	return openDb().then((db) => new Promise((resolve, reject) => {
		const request = work(db.transaction(STORE, mode).objectStore(STORE));
		request.onsuccess = () => {
			resolve(request.result);
			db.close();
		};
		request.onerror = () => {
			reject(request.error ?? /* @__PURE__ */ new Error("Local shelf failed."));
			db.close();
		};
	}));
}
function idbPut(key, blob) {
	return run("readwrite", (store) => store.put(blob, key)).then(() => void 0);
}
function idbGet(key) {
	return run("readonly", (store) => store.get(key)).then((value) => value ?? null);
}
function idbDel(key) {
	return run("readwrite", (store) => store.delete(key)).then(() => void 0);
}
//#endregion
export { idbGet as n, idbPut as r, idbDel as t };
