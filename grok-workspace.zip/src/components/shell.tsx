import { Link, useRouterState } from "@tanstack/react-router";
import { Clapperboard, Library, Search } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { SearchDialog } from "@/components/search-dialog";
import { BROWSE_DEFAULT } from "@/lib/anime";
import { useUi } from "@/lib/ui";
import { useVaultReady } from "@/lib/vault";

const LINKS = [
  { to: "/", label: "Home", search: undefined },
  { to: "/browse", label: "Browse", search: BROWSE_DEFAULT },
  { to: "/schedule", label: "Schedule", search: undefined },
  { to: "/originals", label: "Originals", search: undefined },
  { to: "/library", label: "Library", search: undefined },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  useVaultReady();
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const setSearchOpen = useUi((state) => state.setSearchOpen);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing = target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA");
      if (event.key === "/" && !typing) {
        event.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [setSearchOpen]);

  return (
    <div className="min-h-screen bg-bg text-fg">
      <a href="#content" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:bg-surface focus:px-3 focus:py-2">
        Skip to content
      </a>
      <header className="sticky top-0 z-30 border-b border-line bg-bg/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">
          <Link to="/" className="flex items-center gap-2">
            <span className="grid size-9 place-items-center rounded-full border border-accent text-sm text-accent">灯</span>
            <span className="leading-none">
              <span className="block text-xs tracking-widest text-muted">DALTRON</span>
              <span className="font-display text-xl italic text-fg">Aniverse</span>
            </span>
          </Link>
          <nav className="ml-2 hidden items-center gap-1 md:flex">
            {LINKS.map((link) => {
              const active = link.to === "/" ? pathname === "/" : pathname.startsWith(link.to);
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  search={link.search}
                  className={`rounded-full px-3 py-2 text-sm ${active ? "bg-surface text-fg" : "text-muted hover:text-fg"}`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>
          <button type="button" className="btn btn-ghost ml-auto" onClick={() => setSearchOpen(true)}>
            <Search className="size-4" aria-hidden="true" />
            Search
          </button>
        </div>
        <nav className="flex gap-1 overflow-x-auto px-4 pb-3 md:hidden">
          {LINKS.map((link) => {
            const active = link.to === "/" ? pathname === "/" : pathname.startsWith(link.to);
            return (
              <Link
                key={link.to}
                to={link.to}
                search={link.search}
                className={`shrink-0 rounded-full px-3 py-2 text-sm ${active ? "bg-surface text-fg" : "text-muted"}`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
      </header>
      <main id="content" className="mx-auto max-w-6xl px-4 py-6">
        {children}
      </main>
      <footer className="mx-auto mt-8 max-w-6xl border-t border-line px-4 py-8 text-sm text-muted">
        <div className="flex items-center gap-2 text-fg">
          <Clapperboard className="size-4 text-accent" aria-hidden="true" />
          <span className="font-display text-2xl italic">Daltron Aniverse</span>
        </div>
        <p className="mt-3 max-w-2xl">
          A local-first anime house. Catalog and cover art come from AniList. Official trailers stream from their
          YouTube uploads. Lantern Run is an original reel you can play or download. Videos you add stay in this
          browser — nothing is uploaded.
        </p>
        <p className="mt-3 flex items-center gap-2">
          <Library className="size-4" aria-hidden="true" />
          Your shelf lives on this device.
        </p>
      </footer>
      <SearchDialog />
    </div>
  );
}
