import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Play, Star } from "lucide-react";
import { useRef, useState, type ReactNode } from "react";
import { BROWSE_DEFAULT, metaLine, scoreText, type AnimeCard } from "@/lib/anime";

export function Poster({
  src,
  title,
  className = "",
}: {
  src: string | null;
  title: string;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);
  if (!src || failed) {
    return (
      <div className={`poster-frame flex items-end bg-surface-2 p-3 ${className}`}>
        <span className="font-display text-2xl leading-none text-fg">{title.slice(0, 1)}</span>
      </div>
    );
  }
  return (
    <img
      src={src}
      alt=""
      className={`poster-frame h-full w-full object-cover ${className}`}
      onError={() => setFailed(true)}
    />
  );
}

export function TitleCard({ anime }: { anime: AnimeCard }) {
  const score = scoreText(anime.score);
  return (
    <Link
      to="/anime/$id"
      params={{ id: String(anime.id) }}
      className="group w-36 sm:w-44"
    >
      <div className="overflow-hidden rounded-card border border-line bg-surface">
        <Poster src={anime.cover} title={anime.title} className="transition duration-200 group-hover:scale-105" />
      </div>
      <p className="mt-2 line-clamp-2 text-sm font-medium text-fg">{anime.title}</p>
      <p className="mt-0.5 flex items-center gap-1 text-xs text-muted">
        {score ? (
          <>
            <Star className="size-3 text-accent" aria-hidden="true" />
            <span>{score}</span>
            <span>·</span>
          </>
        ) : null}
        <span>{anime.formatLabel}</span>
      </p>
    </Link>
  );
}

export function Rail({
  title,
  eyebrow,
  children,
  seeAll,
}: {
  title: string;
  eyebrow?: string;
  children: ReactNode;
  seeAll?: boolean;
}) {
  const scroller = useRef<HTMLDivElement>(null);
  const move = (direction: number) => {
    scroller.current?.scrollBy({ left: direction * 520, behavior: "smooth" });
  };
  return (
    <section className="mt-10">
      <div className="mb-3 flex items-end justify-between gap-3">
        <div>
          {eyebrow ? <p className="text-xs tracking-widest text-accent uppercase">{eyebrow}</p> : null}
          <h2 className="font-display text-3xl leading-none text-fg">{title}</h2>
        </div>
        <div className="flex items-center gap-2">
          {seeAll ? (
            <Link to="/browse" search={BROWSE_DEFAULT} className="text-sm text-muted hover:text-fg">
              See all
            </Link>
          ) : null}
          <button type="button" className="btn btn-ghost btn-icon" aria-label="Scroll left" onClick={() => move(-1)}>
            <ChevronLeft className="size-4" />
          </button>
          <button type="button" className="btn btn-ghost btn-icon" aria-label="Scroll right" onClick={() => move(1)}>
            <ChevronRight className="size-4" />
          </button>
        </div>
      </div>
      <div className="rail" ref={scroller}>
        {children}
      </div>
    </section>
  );
}

export function Hero({ anime }: { anime: AnimeCard }) {
  const score = scoreText(anime.score);
  return (
    <section className="hero overflow-hidden rounded-card border border-line">
      {anime.banner || anime.cover ? (
        <img
          src={anime.banner || anime.cover || ""}
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
      ) : null}
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/80 to-bg/20" />
      <div className="relative z-10 max-w-2xl px-5 py-8 sm:px-8 sm:py-10">
        <p className="text-xs tracking-widest text-accent uppercase">Now in the house</p>
        <h1 className="mt-2 font-display text-5xl leading-none text-fg sm:text-7xl">{anime.title}</h1>
        <p className="mt-3 text-sm text-muted">{metaLine(anime)}</p>
        {score ? (
          <p className="mt-2 inline-flex items-center gap-1 text-sm text-fg">
            <Star className="size-4 text-accent" aria-hidden="true" />
            {score}
            <span className="text-muted">/ 10</span>
          </p>
        ) : null}
        <p className="mt-4 line-clamp-3 max-w-xl text-sm text-fg/90 sm:text-base">{anime.synopsis}</p>
        <div className="mt-6 flex flex-wrap gap-3">
          {anime.trailerId ? (
            <Link to="/watch/$kind/$id" params={{ kind: "trailer", id: String(anime.id) }} search={{ ep: 1 }} className="btn btn-accent">
              <Play className="size-4" aria-hidden="true" />
              Play trailer
            </Link>
          ) : null}
          <Link to="/anime/$id" params={{ id: String(anime.id) }} className="btn btn-ghost">
            Title page
          </Link>
        </div>
      </div>
    </section>
  );
}

export function Warning({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p className="mt-4 rounded-card border border-line bg-surface px-4 py-3 text-sm text-muted">{message}</p>
  );
}
