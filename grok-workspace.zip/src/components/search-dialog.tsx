import * as Dialog from "@radix-ui/react-dialog";
import { Link } from "@tanstack/react-router";
import { Search } from "lucide-react";
import { useEffect, useState } from "react";
import { Poster } from "@/components/media";
import { searchAnime } from "@/lib/catalog.functions";
import { scoreText, type AnimeCard } from "@/lib/anime";
import { useUi } from "@/lib/ui";

export function SearchDialog() {
  const open = useUi((state) => state.searchOpen);
  const setOpen = useUi((state) => state.setSearchOpen);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<AnimeCard[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setBusy(false);
      return;
    }
    let cancelled = false;
    setBusy(true);
    const timer = window.setTimeout(() => {
      void searchAnime({ data: { query: trimmed } })
        .then((items) => {
          if (!cancelled) setResults(items);
        })
        .catch(() => {
          if (!cancelled) setResults([]);
        })
        .finally(() => {
          if (!cancelled) setBusy(false);
        });
    }, 250);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [open, query]);

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-40 bg-bg/80" />
        <Dialog.Content className="search-panel fixed top-24 left-1/2 z-50 -translate-x-1/2 rounded-card border border-line bg-surface p-4 shadow-none">
          <Dialog.Title className="font-display text-2xl text-fg">Find a title</Dialog.Title>
          <Dialog.Description className="text-sm text-muted">Search the AniList catalog. Press / anywhere.</Dialog.Description>
          <label className="mt-4 flex items-center gap-2 rounded-full border border-line bg-bg px-3">
            <Search className="size-4 text-muted" aria-hidden="true" />
            <input
              autoFocus
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Title, romaji, or nickname"
              className="h-11 w-full bg-transparent text-fg outline-none"
            />
          </label>
          <div className="mt-4 max-h-96 space-y-2 overflow-y-auto">
            {busy ? <p className="text-sm text-muted">Looking through the catalog…</p> : null}
            {!busy && query.trim().length >= 2 && results.length === 0 ? (
              <p className="text-sm text-muted">Nothing matches that.</p>
            ) : null}
            {results.map((anime) => (
              <Link
                key={anime.id}
                to="/anime/$id"
                params={{ id: String(anime.id) }}
                onClick={() => setOpen(false)}
                className="flex items-center gap-3 rounded-card p-2 hover:bg-surface-2"
              >
                <div className="w-12 overflow-hidden rounded-md">
                  <Poster src={anime.cover} title={anime.title} />
                </div>
                <span>
                  <span className="block text-sm text-fg">{anime.title}</span>
                  <span className="block text-xs text-muted">
                    {anime.formatLabel}
                    {scoreText(anime.score) ? ` · ${scoreText(anime.score)}` : ""}
                  </span>
                </span>
              </Link>
            ))}
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
