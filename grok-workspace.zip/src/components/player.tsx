import { Download, Maximize, Pause, Play, Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { clock } from "@/lib/anime";
import type { ProgressEntry } from "@/lib/vault";
import { useVault } from "@/lib/vault";

export type PlayerEpisode = {
  label: string;
  href: string;
  active: boolean;
};

export function CinemaPlayer({
  src,
  poster,
  title,
  subtitle,
  progressKey,
  downloadName,
  startAt = 0,
  episodes,
}: {
  src: string;
  poster?: string | null;
  title: string;
  subtitle: string;
  progressKey: string;
  downloadName?: string;
  startAt?: number;
  episodes?: PlayerEpisode[];
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const setProgress = useVault((state) => state.setProgress);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(startAt);
  const [duration, setDuration] = useState(0);
  const [muted, setMuted] = useState(false);
  const [rate, setRate] = useState(1);
  const [failed, setFailed] = useState(false);
  const applied = useRef("");

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    setFailed(false);
    const token = `${src}:${Math.floor(startAt)}`;
    const seek = () => {
      if (applied.current === token) return;
      const length = video.duration || 0;
      if (startAt > 1 && length > 0 && startAt < length - 1) {
        video.currentTime = startAt;
        applied.current = token;
      }
    };
    setDuration(video.duration || 0);
    seek();
    const onMeta = () => {
      setDuration(video.duration || 0);
      seek();
    };
    const onTime = () => setTime(video.currentTime || 0);
    const onPlay = () => setPlaying(true);
    const onPause = () => setPlaying(false);
    const onError = () => setFailed(true);
    video.addEventListener("loadedmetadata", onMeta);
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("error", onError);
    return () => {
      video.removeEventListener("loadedmetadata", onMeta);
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("error", onError);
    };
  }, [src, startAt]);

  useEffect(() => {
    const entry: ProgressEntry = {
      key: progressKey,
      title,
      subtitle,
      poster: poster ?? null,
      href: typeof window === "undefined" ? "" : `${window.location.pathname}${window.location.search}`,
      seconds: time,
      duration: duration || 0,
      updated: Date.now(),
    };
    if (time < 0.5) return;
    const handle = window.setTimeout(() => setProgress(entry), 400);
    return () => window.clearTimeout(handle);
  }, [duration, poster, progressKey, setProgress, subtitle, time, title]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      const video = videoRef.current;
      if (!video) return;
      if (event.key === " " || event.key === "k") {
        event.preventDefault();
        if (video.paused) void video.play();
        else video.pause();
      } else if (event.key === "ArrowRight") {
        video.currentTime = Math.min(video.duration || 0, video.currentTime + 5);
      } else if (event.key === "ArrowLeft") {
        video.currentTime = Math.max(0, video.currentTime - 5);
      } else if (event.key === "f") {
        toggleFullscreen();
      } else if (event.key === "m") {
        video.muted = !video.muted;
        setMuted(video.muted);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const toggleFullscreen = () => {
    const stage = stageRef.current;
    if (!stage) return;
    if (document.fullscreenElement) void document.exitFullscreen();
    else void stage.requestFullscreen();
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) void video.play();
    else video.pause();
  };

  const cycleRate = () => {
    const video = videoRef.current;
    if (!video) return;
    const next = rate === 1 ? 1.25 : rate === 1.25 ? 1.5 : rate === 1.5 ? 2 : 1;
    video.playbackRate = next;
    setRate(next);
  };

  return (
    <div>
      <div className="stage" ref={stageRef}>
        <video
          ref={videoRef}
          src={src}
          poster={poster ?? undefined}
          className="banner-frame w-full bg-bg object-contain"
          playsInline
          preload="metadata"
          onClick={togglePlay}
        />
        {failed ? (
          <p className="absolute inset-0 grid place-items-center bg-bg/80 px-6 text-center text-sm text-muted">
            This reel could not be opened.
          </p>
        ) : null}
        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg via-bg/80 to-transparent p-3 sm:p-4">
          <input
            className="scrub"
            type="range"
            min={0}
            max={duration || 0}
            step={0.1}
            value={Math.min(time, duration || 0)}
            aria-label="Seek"
            onChange={(event) => {
              const video = videoRef.current;
              if (!video) return;
              video.currentTime = Number(event.target.value);
            }}
          />
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <button type="button" className="btn btn-accent btn-icon" onClick={togglePlay} aria-label={playing ? "Pause" : "Play"}>
              {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
            </button>
            <span className="text-xs text-fg">
              {clock(time)} / {clock(duration)}
            </span>
            <button type="button" className="btn btn-ghost" onClick={cycleRate}>
              {rate}×
            </button>
            <button
              type="button"
              className="btn btn-ghost btn-icon"
              aria-label={muted ? "Unmute" : "Mute"}
              onClick={() => {
                const video = videoRef.current;
                if (!video) return;
                video.muted = !video.muted;
                setMuted(video.muted);
              }}
            >
              {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
            </button>
            <span className="ml-auto flex gap-2">
              {downloadName ? (
                <a className="btn btn-ghost" href={src} download={downloadName}>
                  <Download className="size-4" aria-hidden="true" />
                  Download
                </a>
              ) : null}
              <button type="button" className="btn btn-ghost btn-icon" aria-label="Fullscreen" onClick={toggleFullscreen}>
                <Maximize className="size-4" />
              </button>
            </span>
          </div>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs tracking-widest text-accent uppercase">{subtitle}</p>
          <h1 className="font-display text-4xl text-fg">{title}</h1>
        </div>
      </div>
      <p className="mt-2 text-xs text-muted">Space plays and pauses. Arrows skip 5 seconds. F is fullscreen. M mutes.</p>
      {episodes && episodes.length > 0 ? (
        <div className="mt-5 grid gap-2 sm:grid-cols-3">
          {episodes.map((episode) => (
            <a
              key={episode.href}
              href={episode.href}
              className={`rounded-card border px-3 py-3 text-sm ${episode.active ? "border-accent bg-surface text-fg" : "border-line bg-surface text-muted"}`}
            >
              {episode.label}
            </a>
          ))}
        </div>
      ) : null}
    </div>
  );
}
