import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, Play } from "lucide-react";
import { Shell } from "@/components/shell";
import { clock } from "@/lib/anime";
import { lanternRun } from "@/lib/originals";

export const Route = createFileRoute("/originals")({
  component: OriginalsPage,
});

function OriginalsPage() {
  return (
    <Shell>
      <section className="overflow-hidden rounded-card border border-line">
        <img src={lanternRun.banner} alt="" className="banner-frame w-full object-cover" />
      </section>
      <p className="mt-6 text-xs tracking-widest text-accent uppercase">Daltron original · {lanternRun.year}</p>
      <h1 className="font-display text-6xl text-fg">{lanternRun.title}</h1>
      <p className="mt-3 max-w-2xl text-sm text-muted">{lanternRun.logline}</p>
      <div className="mt-6 grid gap-4">
        {lanternRun.episodes.map((episode) => (
          <article key={episode.number} className="grid gap-4 rounded-card border border-line bg-surface p-3 sm:grid-cols-[16rem_1fr] sm:items-center">
            <img src={episode.still} alt="" className="banner-frame w-full rounded-md object-cover" />
            <div>
              <p className="text-xs text-accent">Episode {episode.number} · {clock(episode.seconds)}</p>
              <h2 className="font-display text-3xl text-fg">{episode.title}</h2>
              <p className="mt-1 text-sm text-muted">{episode.blurb}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link
                  to="/watch/$kind/$id"
                  params={{ kind: "original", id: lanternRun.slug }}
                  search={{ ep: episode.number }}
                  className="btn btn-accent"
                >
                  <Play className="size-4" aria-hidden="true" />
                  Play
                </Link>
                <a className="btn btn-ghost" href={episode.src} download={`lantern-run-ep${episode.number}.mp4`}>
                  <Download className="size-4" aria-hidden="true" />
                  Download
                </a>
              </div>
            </div>
          </article>
        ))}
      </div>
    </Shell>
  );
}
