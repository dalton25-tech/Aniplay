import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Bookmark, BookmarkCheck, Play } from "lucide-react";
import { toast } from "sonner";
import { Poster, Rail, Warning } from "@/components/media";
import { Shell } from "@/components/shell";
import { BROWSE_DEFAULT, metaLine, scoreText } from "@/lib/anime";
import { getAnime } from "@/lib/catalog.functions";
import { idbDel, idbPut } from "@/lib/idb";
import { useVault, useVaultReady, type Shelf, type ShelfEpisode } from "@/lib/vault";

export const Route = createFileRoute("/anime/$id")({
  loader: async ({ params }) => {
    const id = Number(params.id);
    if (!Number.isFinite(id)) throw notFound();
    const anime = await getAnime({ data: { id } });
    if (!anime) throw notFound();
    return { anime };
  },
  head: ({ loaderData }) => ({
    meta: [{ title: loaderData ? `${loaderData.anime.title} · Daltron Aniverse` : "Daltron Aniverse" }],
  }),
  component: AnimePage,
  notFoundComponent: () => (
    <Shell>
      <h1 className="font-display text-5xl">That title is not in the catalog.</h1>
      <Link to="/browse" search={BROWSE_DEFAULT} className="btn btn-accent mt-4">
        Browse
      </Link>
    </Shell>
  ),
});

function AnimePage() {
  const { anime } = Route.useLoaderData();
  const ready = useVaultReady();
  const watchlist = useVault((state) => state.watchlist);
  const shelves = useVault((state) => state.shelves);
  const toggleList = useVault((state) => state.toggleList);
  const saveShelf = useVault((state) => state.saveShelf);
  const listed = watchlist.some((item) => item.id === anime.id);
  const shelf = shelves.find((item) => item.anilistId === anime.id) ?? null;
  const slotCount = Math.min(anime.episodes ?? 12, 24);
  const score = scoreText(anime.score);

  const ensureShelf = (): Shelf => {
    if (shelf) return shelf;
    const created: Shelf = {
      id: crypto.randomUUID(),
      title: anime.title,
      cover: anime.cover,
      anilistId: anime.id,
      episodes: [],
    };
    saveShelf(created);
    return created;
  };

  const attach = async (number: number, file: File | undefined) => {
    if (!file) return;
    const current = ensureShelf();
    const previous = current.episodes.find((episode) => episode.number === number);
    const episode: ShelfEpisode = {
      id: crypto.randomUUID(),
      number,
      title: `Episode ${number}`,
      fileName: file.name,
      mime: file.type || "video/mp4",
      bytes: file.size,
    };
    try {
      await idbPut(`ep:${episode.id}`, file);
      if (previous) await idbDel(`ep:${previous.id}`);
      saveShelf({
        ...current,
        episodes: [...current.episodes.filter((item) => item.number !== number), episode].sort(
          (a, b) => a.number - b.number,
        ),
      });
      toast.success(`Episode ${number} is on this device.`);
    } catch {
      toast.error("This browser could not store that file.");
    }
  };

  return (
    <Shell>
      <section className="overflow-hidden rounded-card border border-line">
        <div className="relative">
          {anime.banner ? <img src={anime.banner} alt="" className="h-64 w-full object-cover sm:h-80" /> : <div className="h-40 bg-surface" />}
          <div className="absolute inset-0 bg-gradient-to-t from-bg to-transparent" />
        </div>
        <div className="grid gap-5 px-4 pb-6 sm:grid-cols-[11rem_1fr] sm:px-6">
          <div className="-mt-16 w-40 overflow-hidden rounded-card border border-line">
            <Poster src={anime.cover} title={anime.title} />
          </div>
          <div>
            <p className="text-xs tracking-widest text-accent uppercase">{metaLine(anime)}</p>
            <h1 className="font-display text-5xl leading-none text-fg">{anime.title}</h1>
            {anime.native ? <p className="mt-1 text-sm text-muted">{anime.native}</p> : null}
            {score ? <p className="mt-2 text-sm text-fg">{score} / 10</p> : null}
            <p className="mt-3 max-w-2xl text-sm text-muted">{anime.synopsis || "No synopsis yet."}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {anime.genres.map((genre) => (
                <Link
                  key={genre}
                  to="/browse"
                  search={{ ...BROWSE_DEFAULT, genre }}
                  className="rounded-full border border-line px-3 py-1 text-xs text-muted"
                >
                  {genre}
                </Link>
              ))}
            </div>
            {anime.studios.length > 0 ? <p className="mt-3 text-xs text-muted">{anime.studios.join(" · ")}</p> : null}
            <div className="mt-5 flex flex-wrap gap-2">
              {anime.trailerId ? (
                <Link to="/watch/$kind/$id" params={{ kind: "trailer", id: String(anime.id) }} search={{ ep: 1 }} className="btn btn-accent">
                  <Play className="size-4" aria-hidden="true" />
                  Play trailer
                </Link>
              ) : null}
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => toggleList({ id: anime.id, title: anime.title, cover: anime.cover })}
              >
                {listed ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
                {listed ? "On my list" : "My list"}
              </button>
            </div>
          </div>
        </div>
      </section>

      <section className="mt-8">
        <h2 className="font-display text-4xl text-fg">Episodes</h2>
        <p className="mt-2 max-w-2xl text-sm text-muted">
          Trailers play from the official upload. Full episodes are not hosted here. Add a video file you already
          have the right to watch — it stays in this browser, then you can stream it and download it again.
        </p>
        {!ready ? <p className="mt-4 text-sm text-muted">Opening your shelf…</p> : null}
        <div className="mt-4 grid gap-2">
          {Array.from({ length: slotCount }, (_, index) => {
            const number = index + 1;
            const episode = shelf?.episodes.find((item) => item.number === number);
            return (
              <div key={number} className="flex flex-wrap items-center gap-3 rounded-card border border-line bg-surface px-3 py-3">
                <span className="w-10 text-sm text-muted">{number}</span>
                <span className="min-w-0 flex-1 text-sm text-fg">
                  {episode ? episode.fileName : `Episode ${number}`}
                </span>
                {episode ? (
                  <Link
                    to="/watch/$kind/$id"
                    params={{ kind: "shelf", id: shelf?.id ?? "" }}
                    search={{ ep: number }}
                    className="btn btn-accent"
                  >
                    <Play className="size-4" aria-hidden="true" />
                    Play
                  </Link>
                ) : null}
                <label className="btn btn-ghost">
                  {episode ? "Replace" : "Add file"}
                  <input
                    type="file"
                    accept="video/*"
                    className="sr-only"
                    onChange={(event) => {
                      const file = event.target.files?.[0];
                      void attach(number, file);
                      event.target.value = "";
                    }}
                  />
                </label>
              </div>
            );
          })}
        </div>
        {anime.episodes && anime.episodes > slotCount ? (
          <p className="mt-3 text-xs text-muted">Showing the first {slotCount} episodes. Add more from your library.</p>
        ) : null}
      </section>

      {anime.related.length > 0 ? (
        <Rail title="Related">
          {anime.related.map((item) => (
            <Link key={`${item.relation}-${item.id}`} to="/anime/$id" params={{ id: String(item.id) }} className="w-36 sm:w-44">
              <div className="overflow-hidden rounded-card border border-line">
                <Poster src={item.cover} title={item.title} />
              </div>
              <p className="mt-2 line-clamp-2 text-sm text-fg">{item.title}</p>
              <p className="text-xs text-muted capitalize">{item.relation}</p>
            </Link>
          ))}
        </Rail>
      ) : null}
      <Warning message={null} />
    </Shell>
  );
}
