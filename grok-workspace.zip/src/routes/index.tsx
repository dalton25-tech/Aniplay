import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, Play } from "lucide-react";
import { Hero, Rail, TitleCard, Warning } from "@/components/media";
import { Shell } from "@/components/shell";
import { getHome } from "@/lib/catalog.functions";
import { lanternRun } from "@/lib/originals";
import { useVault, useVaultReady } from "@/lib/vault";
import { clock } from "@/lib/anime";

export const Route = createFileRoute("/")({
  loader: () => getHome(),
  component: Home,
});

function Home() {
  const data = Route.useLoaderData();
  const ready = useVaultReady();
  const progress = useVault((state) => state.progress);
  const continueItems = Object.values(progress)
    .sort((a, b) => b.updated - a.updated)
    .slice(0, 8);

  return (
    <Shell>
      {data.hero ? <Hero anime={data.hero} /> : <OriginalBillboard />}
      <Warning message={data.warning} />
      <section className="mt-10 overflow-hidden rounded-card border border-line bg-surface">
        <div className="grid md:grid-cols-2">
          <img src={lanternRun.banner} alt="" className="h-full w-full object-cover" />
          <div className="p-6">
            <p className="text-xs tracking-widest text-accent uppercase">Original reel · stream and download</p>
            <h2 className="mt-2 font-display text-5xl text-fg">{lanternRun.title}</h2>
            <p className="mt-3 text-sm text-muted">{lanternRun.logline}</p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Link
                to="/watch/$kind/$id"
                params={{ kind: "original", id: lanternRun.slug }}
                search={{ ep: 1 }}
                className="btn btn-accent"
              >
                <Play className="size-4" aria-hidden="true" />
                Play episode 1
              </Link>
              <a className="btn btn-ghost" href={lanternRun.episodes[0].src} download="lantern-run-ep1.mp4">
                <Download className="size-4" aria-hidden="true" />
                Download
              </a>
            </div>
          </div>
        </div>
      </section>
      {ready && continueItems.length > 0 ? (
        <Rail title="Continue" eyebrow="Your seat">
          {continueItems.map((item) => (
            <a key={item.key} href={item.href} className="w-64">
              <div className="overflow-hidden rounded-card border border-line bg-surface">
                {item.poster ? <img src={item.poster} alt="" className="banner-frame w-full object-cover" /> : <div className="banner-frame bg-surface-2" />}
                <div className="p-3">
                  <p className="line-clamp-1 text-sm text-fg">{item.title}</p>
                  <p className="text-xs text-muted">{item.subtitle}</p>
                  <div className="mt-2 h-1 overflow-hidden rounded-full bg-line">
                    <div
                      className="h-full bg-accent"
                      style={{ width: `${item.duration ? Math.min(100, (item.seconds / item.duration) * 100) : 0}%` }}
                    />
                  </div>
                  <p className="mt-1 text-xs text-muted">{clock(item.seconds)}</p>
                </div>
              </div>
            </a>
          ))}
        </Rail>
      ) : null}
      <Rail title="Lantern Run" eyebrow="Playable now">
        {lanternRun.episodes.map((episode) => (
          <Link
            key={episode.number}
            to="/watch/$kind/$id"
            params={{ kind: "original", id: lanternRun.slug }}
            search={{ ep: episode.number }}
            className="w-64"
          >
            <div className="overflow-hidden rounded-card border border-line">
              <img src={episode.still} alt="" className="banner-frame w-full object-cover" />
            </div>
            <p className="mt-2 text-sm text-fg">
              {episode.number}. {episode.title}
            </p>
            <p className="text-xs text-muted">{episode.blurb}</p>
          </Link>
        ))}
      </Rail>
      {data.trending.length > 0 ? (
        <Rail title="Trending" eyebrow="Catalog" seeAll>
          {data.trending.map((anime) => (
            <TitleCard key={anime.id} anime={anime} />
          ))}
        </Rail>
      ) : null}
      {data.seasonal.length > 0 ? (
        <Rail title={data.seasonName} eyebrow="Airing" seeAll>
          {data.seasonal.map((anime) => (
            <TitleCard key={anime.id} anime={anime} />
          ))}
        </Rail>
      ) : null}
      {data.popular.length > 0 ? (
        <Rail title="Most watched" eyebrow="All time" seeAll>
          {data.popular.map((anime) => (
            <TitleCard key={anime.id} anime={anime} />
          ))}
        </Rail>
      ) : null}
    </Shell>
  );
}

function OriginalBillboard() {
  return (
    <section className="hero overflow-hidden rounded-card border border-line">
      <img src={lanternRun.banner} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/70 to-transparent" />
      <div className="relative z-10 max-w-xl px-6 py-10">
        <h1 className="font-display text-6xl text-fg">{lanternRun.title}</h1>
        <p className="mt-3 text-sm text-fg">{lanternRun.logline}</p>
      </div>
    </section>
  );
}
