import { createFileRoute, Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { Shell } from "@/components/shell";
import { Poster, Warning } from "@/components/media";
import { getSchedule } from "@/lib/catalog.functions";

export const Route = createFileRoute("/schedule")({
  loader: () => getSchedule(),
  component: SchedulePage,
});

function SchedulePage() {
  const data = Route.useLoaderData();
  const groups = new Map<string, typeof data.items>();
  for (const item of data.items) {
    const key = format(new Date(item.airingAt * 1000), "EEEE, MMM d");
    const list = groups.get(key) ?? [];
    list.push(item);
    groups.set(key, list);
  }

  return (
    <Shell>
      <p className="text-xs tracking-widest text-accent uppercase">Broadcast</p>
      <h1 className="font-display text-5xl text-fg">Airing next</h1>
      <p className="mt-2 max-w-xl text-sm text-muted">
        The next episode time for shows currently airing. Times follow this device.
      </p>
      <Warning message={data.warning} />
      {[...groups.entries()].map(([day, items]) => (
        <section key={day} className="mt-8">
          <h2 className="font-display text-3xl text-fg">{day}</h2>
          <ul className="mt-3 divide-y divide-line rounded-card border border-line bg-surface">
            {items.map((item) => (
              <li key={item.id}>
                <Link to="/anime/$id" params={{ id: String(item.id) }} className="flex items-center gap-3 p-3">
                  <div className="w-12 overflow-hidden rounded-md">
                    <Poster src={item.cover} title={item.title} />
                  </div>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm text-fg">{item.title}</span>
                    <span className="block text-xs text-muted">Episode {item.episode}</span>
                  </span>
                  <span className="text-sm text-accent">{format(new Date(item.airingAt * 1000), "h:mm a")}</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ))}
      {data.items.length === 0 && !data.warning ? (
        <p className="mt-8 text-sm text-muted">No upcoming episodes were listed.</p>
      ) : null}
    </Shell>
  );
}
