import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { CinemaPlayer } from "@/components/player";
import { Shell } from "@/components/shell";
import { getAnime } from "@/lib/catalog.functions";
import { idbGet } from "@/lib/idb";
import { findOriginal } from "@/lib/originals";
import { useVault, useVaultReady } from "@/lib/vault";

export const Route = createFileRoute("/watch/$kind/$id")({
  validateSearch: (search: Record<string, unknown>) => ({
    ep: Math.max(1, Number(search.ep) || 1),
  }),
  loader: async ({ params }) => {
    if (params.kind !== "trailer") return { anime: null };
    const anime = await getAnime({ data: { id: Number(params.id) } });
    return { anime };
  },
  component: WatchPage,
});

function WatchPage() {
  const { kind, id } = Route.useParams();
  const { ep } = Route.useSearch();
  const { anime } = Route.useLoaderData();
  if (kind === "original") return <OriginalWatch slug={id} episode={ep} />;
  if (kind === "shelf") return <ShelfWatch id={id} episode={ep} />;
  if (kind === "trailer") return <TrailerWatch anime={anime} />;
  return (
    <Shell>
      <h1 className="font-display text-5xl">That screening does not exist.</h1>
    </Shell>
  );
}

function OriginalWatch({ slug, episode }: { slug: string; episode: number }) {
  const series = findOriginal(slug);
  const current = series?.episodes.find((item) => item.number === episode) ?? series?.episodes[0];
  const progress = useVault((state) => (current ? state.progress[`original:${series?.slug}:${current.number}`] : undefined));
  if (!series || !current) {
    return (
      <Shell>
        <h1 className="font-display text-5xl">That reel is not on the program.</h1>
      </Shell>
    );
  }
  return (
    <Shell>
      <CinemaPlayer
        src={current.src}
        poster={current.still}
        title={current.title}
        subtitle={`${series.title} · episode ${current.number}`}
        progressKey={`original:${series.slug}:${current.number}`}
        downloadName={`${series.slug}-ep${current.number}.mp4`}
        startAt={progress?.seconds ?? 0}
        episodes={series.episodes.map((item) => ({
          label: `${item.number}. ${item.title}`,
          href: `/watch/original/${series.slug}?ep=${item.number}`,
          active: item.number === current.number,
        }))}
      />
      <p className="mt-4 text-sm text-muted">{current.blurb}</p>
      <Link to="/originals" className="mt-4 inline-block text-sm text-accent">
        All Lantern Run reels
      </Link>
    </Shell>
  );
}

function TrailerWatch({ anime }: { anime: Awaited<ReturnType<typeof getAnime>> }) {
  const setProgress = useVault((state) => state.setProgress);
  useEffect(() => {
    if (!anime) return;
    setProgress({
      key: `trailer:${anime.id}`,
      title: anime.title,
      subtitle: "Official trailer",
      poster: anime.cover,
      href: `/watch/trailer/${anime.id}`,
      seconds: 1,
      duration: 1,
      updated: Date.now(),
    });
  }, [anime, setProgress]);

  if (!anime || !anime.trailerId) {
    return (
      <Shell>
        <h1 className="font-display text-5xl">No official trailer is listed.</h1>
        {anime ? (
          <Link to="/anime/$id" params={{ id: String(anime.id) }} className="btn btn-ghost mt-4">
            Back to {anime.title}
          </Link>
        ) : null}
      </Shell>
    );
  }

  return (
    <Shell>
      <p className="text-xs tracking-widest text-accent uppercase">Official trailer</p>
      <h1 className="font-display text-5xl text-fg">{anime.title}</h1>
      <div className="stage mt-4">
        <iframe
          className="banner-frame w-full"
          src={`https://www.youtube-nocookie.com/embed/${anime.trailerId}?rel=0&modestbranding=1`}
          title={`${anime.title} trailer`}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
        />
      </div>
      <p className="mt-3 max-w-2xl text-sm text-muted">
        This streams the official trailer. Daltron does not host full commercial episodes. Add a file you own on the
        title page to play it in the house player.
      </p>
      <Link to="/anime/$id" params={{ id: String(anime.id) }} className="btn btn-ghost mt-4">
        Episode files
      </Link>
    </Shell>
  );
}

function ShelfWatch({ id, episode }: { id: string; episode: number }) {
  const ready = useVaultReady();
  const shelf = useVault((state) => state.shelves.find((item) => item.id === id));
  const current = shelf?.episodes.find((item) => item.number === episode) ?? shelf?.episodes[0];
  const progress = useVault((state) =>
    current ? state.progress[`shelf:${id}:${current.number}`] : undefined,
  );
  const [src, setSrc] = useState<string | null>(null);
  const [missing, setMissing] = useState(false);
  const urlRef = useRef<string | null>(null);

  useEffect(() => {
    if (!current) return;
    let cancelled = false;
    setSrc(null);
    setMissing(false);
    void idbGet(`ep:${current.id}`).then((blob) => {
      if (cancelled) return;
      if (!blob) {
        setMissing(true);
        return;
      }
      const url = URL.createObjectURL(blob);
      urlRef.current = url;
      setSrc(url);
    });
    return () => {
      cancelled = true;
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      urlRef.current = null;
    };
  }, [current?.id]);

  if (!ready) {
    return (
      <Shell>
        <p className="text-sm text-muted">Opening your shelf…</p>
      </Shell>
    );
  }
  if (!shelf || !current) {
    return (
      <Shell>
        <h1 className="font-display text-5xl">That file is not on your shelf.</h1>
        <Link to="/library" className="btn btn-ghost mt-4">
          Library
        </Link>
      </Shell>
    );
  }
  return (
    <Shell>
      {missing ? <p className="text-sm text-muted">The video file is missing from this browser.</p> : null}
      {src ? (
        <CinemaPlayer
          src={src}
          poster={shelf.cover}
          title={shelf.title}
          subtitle={current.title}
          progressKey={`shelf:${shelf.id}:${current.number}`}
          downloadName={current.fileName}
          startAt={progress?.seconds ?? 0}
          episodes={shelf.episodes.map((item) => ({
            label: `${item.number}. ${item.fileName}`,
            href: `/watch/shelf/${shelf.id}?ep=${item.number}`,
            active: item.number === current.number,
          }))}
        />
      ) : !missing ? (
        <p className="text-sm text-muted">Loading the file from this device…</p>
      ) : null}
    </Shell>
  );
}
