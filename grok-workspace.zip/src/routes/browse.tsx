import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Shell } from "@/components/shell";
import { TitleCard, Warning } from "@/components/media";
import { browseAnime } from "@/lib/catalog.functions";
import { BROWSE_DEFAULT, FORMATS, GENRES, SORTS, type BrowseSearch } from "@/lib/anime";

export const Route = createFileRoute("/browse")({
  validateSearch: (search: Record<string, unknown>): BrowseSearch => ({
    genre: typeof search.genre === "string" ? search.genre : "",
    format: typeof search.format === "string" ? search.format : "",
    sort: typeof search.sort === "string" ? search.sort : BROWSE_DEFAULT.sort,
    page: Math.max(1, Number(search.page) || 1),
  }),
  loaderDeps: ({ search }) => search,
  loader: ({ deps }) => browseAnime({ data: deps }),
  component: BrowsePage,
});

function BrowsePage() {
  const search = Route.useSearch();
  const data = Route.useLoaderData();
  const navigate = useNavigate();

  const setSearch = (patch: Partial<BrowseSearch>) => {
    void navigate({ to: "/browse", search: { ...search, ...patch, page: patch.page ?? 1 } });
  };

  return (
    <Shell>
      <p className="text-xs tracking-widest text-accent uppercase">Catalog</p>
      <h1 className="font-display text-5xl text-fg">Browse</h1>
      <div className="mt-4 flex gap-2 overflow-x-auto pb-2">
        <FilterChip active={search.genre === ""} onClick={() => setSearch({ genre: "" })}>
          All genres
        </FilterChip>
        {GENRES.map((genre) => (
          <FilterChip key={genre} active={search.genre === genre} onClick={() => setSearch({ genre })}>
            {genre}
          </FilterChip>
        ))}
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        <FilterChip active={search.format === ""} onClick={() => setSearch({ format: "" })}>
          Any format
        </FilterChip>
        {FORMATS.map((format) => (
          <FilterChip key={format.id} active={search.format === format.id} onClick={() => setSearch({ format: format.id })}>
            {format.label}
          </FilterChip>
        ))}
        <label className="ml-auto flex items-center gap-2 text-sm text-muted">
          Sort
          <select
            className="h-11 rounded-full border border-line bg-surface px-3 text-fg"
            value={search.sort}
            onChange={(event) => setSearch({ sort: event.target.value })}
          >
            {SORTS.map((sort) => (
              <option key={sort.id} value={sort.id}>
                {sort.label}
              </option>
            ))}
          </select>
        </label>
      </div>
      <Warning message={data.warning} />
      {data.items.length === 0 && !data.warning ? (
        <p className="mt-8 text-sm text-muted">Nothing in this cut. Try another genre.</p>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {data.items.map((anime) => (
            <TitleCard key={anime.id} anime={anime} />
          ))}
        </div>
      )}
      <div className="mt-8 flex items-center justify-between">
        <button
          type="button"
          className="btn btn-ghost"
          disabled={search.page <= 1}
          onClick={() => setSearch({ page: search.page - 1 })}
        >
          Previous
        </button>
        <span className="text-sm text-muted">Page {data.page}</span>
        <button
          type="button"
          className="btn btn-ghost"
          disabled={!data.hasNext}
          onClick={() => setSearch({ page: search.page + 1 })}
        >
          Next
        </button>
      </div>
    </Shell>
  );
}

function FilterChip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button type="button" onClick={onClick} className={`btn shrink-0 ${active ? "btn-accent" : "btn-ghost"}`}>
      {children}
    </button>
  );
}
