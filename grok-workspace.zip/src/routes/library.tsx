import { createFileRoute, Link } from "@tanstack/react-router";
import { Download, Play, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Poster } from "@/components/media";
import { Shell } from "@/components/shell";
import { BROWSE_DEFAULT, formatBytes } from "@/lib/anime";
import { idbDel, idbGet, idbPut } from "@/lib/idb";
import { useVault, useVaultReady, type Shelf, type ShelfEpisode } from "@/lib/vault";

export const Route = createFileRoute("/library")({
  component: LibraryPage,
});

function LibraryPage() {
  const ready = useVaultReady();
  const watchlist = useVault((state) => state.watchlist);
  const shelves = useVault((state) => state.shelves);
  const saveShelf = useVault((state) => state.saveShelf);
  const removeShelf = useVault((state) => state.removeShelf);
  const [hot, setHot] = useState(false);
  const [title, setTitle] = useState("");

  const importFiles = async (files: File[], shelfTitle: string) => {
    const videos = files.filter((file) => file.type.startsWith("video/") || /\.(mp4|webm|ogg|mkv|mov)$/i.test(file.name));
    if (videos.length === 0) {
      toast.error("Drop a video file.");
      return;
    }
    const shelf: Shelf = {
      id: crypto.randomUUID(),
      title: shelfTitle.trim() || videos[0].name.replace(/\.[^.]+$/, ""),
      cover: null,
      anilistId: null,
      episodes: [],
    };
    try {
      const episodes: ShelfEpisode[] = [];
      for (let index = 0; index < videos.length; index += 1) {
        const file = videos[index];
        const episode: ShelfEpisode = {
          id: crypto.randomUUID(),
          number: index + 1,
          title: `Episode ${index + 1}`,
          fileName: file.name,
          mime: file.type || "video/mp4",
          bytes: file.size,
        };
        await idbPut(`ep:${episode.id}`, file);
        episodes.push(episode);
      }
      saveShelf({ ...shelf, episodes });
      setTitle("");
      toast.success("Saved on this device.");
    } catch {
      toast.error("This browser could not store that file.");
    }
  };

  const downloadEpisode = async (episode: ShelfEpisode) => {
    const blob = await idbGet(`ep:${episode.id}`);
    if (!blob) {
      toast.error("That file is no longer on this device.");
      return;
    }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = episode.fileName || `episode-${episode.number}.mp4`;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  };

  const deleteShelf = async (shelf: Shelf) => {
    await Promise.all(shelf.episodes.map((episode) => idbDel(`ep:${episode.id}`)));
    removeShelf(shelf.id);
  };

  return (
    <Shell>
      <p className="text-xs tracking-widest text-accent uppercase">On this device</p>
      <h1 className="font-display text-5xl text-fg">Library</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted">
        Add videos you already own. Daltron plays them here and lets you download them back. They never leave this
        browser.
      </p>

      <form
        className={`drop-zone mt-6 p-5 ${hot ? "is-hot" : ""}`}
        onDragOver={(event) => {
          event.preventDefault();
          setHot(true);
        }}
        onDragLeave={() => setHot(false)}
        onDrop={(event) => {
          event.preventDefault();
          setHot(false);
          void importFiles(Array.from(event.dataTransfer.files), title);
        }}
        onSubmit={(event) => {
          event.preventDefault();
          const input = event.currentTarget.elements.namedItem("files");
          if (input instanceof HTMLInputElement && input.files) {
            void importFiles(Array.from(input.files), title);
            input.value = "";
          }
        }}
      >
        <label className="block text-sm text-muted" htmlFor="shelf-title">
          Shelf name
        </label>
        <input
          id="shelf-title"
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Optional — otherwise the file name is used"
          className="mt-2 h-11 w-full rounded-full border border-line bg-bg px-4 text-fg outline-none"
        />
        <label className="btn btn-accent mt-4">
          Choose videos
          <input
            name="files"
            type="file"
            accept="video/*"
            multiple
            className="sr-only"
            onChange={(event) => {
              if (event.target.files?.length) void importFiles(Array.from(event.target.files), title);
              event.target.value = "";
            }}
          />
        </label>
        <button type="submit" className="btn btn-ghost mt-4 ml-2">
          Save to library
        </button>
        <p className="mt-3 text-xs text-muted">Or drop files on this panel.</p>
      </form>

      {!ready ? <p className="mt-6 text-sm text-muted">Opening your shelf…</p> : null}

      <section className="mt-8">
        <h2 className="font-display text-3xl">My list</h2>
        {watchlist.length === 0 ? (
          <p className="mt-2 text-sm text-muted">
            Titles you bookmark show up here.{" "}
            <Link to="/browse" search={BROWSE_DEFAULT} className="text-fg">
              Browse the catalog
            </Link>
            .
          </p>
        ) : (
          <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-6">
            {watchlist.map((item) => (
              <Link key={item.id} to="/anime/$id" params={{ id: String(item.id) }} className="w-full">
                <div className="overflow-hidden rounded-card border border-line">
                  <Poster src={item.cover} title={item.title} />
                </div>
                <p className="mt-2 line-clamp-2 text-sm">{item.title}</p>
              </Link>
            ))}
          </div>
        )}
      </section>

      <section className="mt-10">
        <h2 className="font-display text-3xl">Shelves</h2>
        {shelves.length === 0 ? <p className="mt-2 text-sm text-muted">No videos saved yet.</p> : null}
        <div className="mt-4 space-y-4">
          {shelves.map((shelf) => (
            <article key={shelf.id} className="rounded-card border border-line bg-surface p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="font-display text-3xl text-fg">{shelf.title}</h3>
                  <p className="text-xs text-muted">{shelf.episodes.length} files</p>
                </div>
                <button type="button" className="btn btn-ghost" onClick={() => void deleteShelf(shelf)}>
                  <Trash2 className="size-4" aria-hidden="true" />
                  Remove
                </button>
              </div>
              <ul className="mt-3 divide-y divide-line">
                {shelf.episodes.map((episode) => (
                  <li key={episode.id} className="flex flex-wrap items-center gap-2 py-3">
                    <span className="w-8 text-sm text-muted">{episode.number}</span>
                    <span className="min-w-0 flex-1 truncate text-sm">{episode.fileName}</span>
                    <span className="text-xs text-muted">{formatBytes(episode.bytes)}</span>
                    <Link
                      to="/watch/$kind/$id"
                      params={{ kind: "shelf", id: shelf.id }}
                      search={{ ep: episode.number }}
                      className="btn btn-accent"
                    >
                      <Play className="size-4" />
                      Play
                    </Link>
                    <button type="button" className="btn btn-ghost" onClick={() => void downloadEpisode(episode)}>
                      <Download className="size-4" />
                      Download
                    </button>
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>
    </Shell>
  );
}
