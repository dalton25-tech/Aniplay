import { createServerFn } from "@tanstack/react-start";
import {
  type AnimeCard,
  type AnimeDetail,
  type BrowseSearch,
  type RelatedCard,
  currentSeason,
  formatLabel,
  seasonLabel,
  statusLabel,
} from "@/lib/anime";

const ENDPOINT = "https://graphql.anilist.co";
const TTL = 5 * 60 * 1000;

type CacheEntry = { at: number; value: unknown };
const memory = new Map<string, CacheEntry>();

type RawMedia = {
  id: number;
  title?: { romaji?: string | null; english?: string | null; native?: string | null } | null;
  description?: string | null;
  coverImage?: { extraLarge?: string | null; large?: string | null } | null;
  bannerImage?: string | null;
  episodes?: number | null;
  duration?: number | null;
  status?: string | null;
  season?: string | null;
  seasonYear?: number | null;
  format?: string | null;
  averageScore?: number | null;
  genres?: string[] | null;
  studios?: { nodes?: { name?: string | null }[] | null } | null;
  trailer?: { id?: string | null; site?: string | null } | null;
  nextAiringEpisode?: { episode?: number | null; airingAt?: number | null } | null;
};

const CARD_FIELDS = `
  id
  title { romaji english native }
  description(asHtml: false)
  coverImage { extraLarge large }
  bannerImage
  episodes
  duration
  status
  season
  seasonYear
  format
  averageScore
  genres
  studios(isMain: true) { nodes { name } }
  trailer { id site }
  nextAiringEpisode { episode airingAt }
`;

function cleanSynopsis(value: string | null | undefined, max: number): string {
  if (!value) return "";
  const text = value
    .replace(/<br\s*\/?>/gi, " ")
    .replace(/<[^>]+>/g, "")
    .replace(/"/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/\s*\(Source:[\s\S]*$/i, "")
    .replace(/\s+/g, " ")
    .trim();
  if (text.length <= max) return text;
  return `${text.slice(0, max - 1).trimEnd()}…`;
}

function mapCard(raw: RawMedia, synopsisMax = 280): AnimeCard {
  const romaji = raw.title?.romaji?.trim() || "Untitled";
  const english = raw.title?.english?.trim();
  const next = raw.nextAiringEpisode;
  const trailerSite = raw.trailer?.site?.toLowerCase();
  return {
    id: raw.id,
    title: english || romaji,
    romaji,
    native: raw.title?.native ?? null,
    synopsis: cleanSynopsis(raw.description, synopsisMax),
    cover: raw.coverImage?.extraLarge || raw.coverImage?.large || null,
    banner: raw.bannerImage ?? null,
    episodes: raw.episodes ?? null,
    duration: raw.duration ?? null,
    status: raw.status ?? "",
    statusLabel: statusLabel(raw.status),
    seasonLabel: seasonLabel(raw.season, raw.seasonYear),
    format: raw.format ?? "",
    formatLabel: formatLabel(raw.format),
    score: raw.averageScore ?? null,
    genres: raw.genres ?? [],
    studios: (raw.studios?.nodes ?? []).map((node) => node.name).filter((name): name is string => Boolean(name)),
    trailerId: trailerSite === "youtube" && raw.trailer?.id ? raw.trailer.id : null,
    nextEpisode:
      next?.episode && next.airingAt
        ? { episode: next.episode, airingAt: next.airingAt }
        : null,
  };
}

async function gql<T>(query: string, variables: Record<string, unknown>): Promise<T> {
  const response = await fetch(ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ query, variables }),
    signal: AbortSignal.timeout(12000),
  });
  if (!response.ok) throw new Error(`Catalog is unavailable (${response.status}).`);
  const json = (await response.json()) as { data?: T; errors?: { message?: string }[] };
  if (json.errors?.length) throw new Error(json.errors[0]?.message || "Catalog request failed.");
  if (!json.data) throw new Error("Catalog returned nothing.");
  return json.data;
}

async function cached<T>(key: string, load: () => Promise<T>): Promise<T> {
  const hit = memory.get(key);
  if (hit && Date.now() - hit.at < TTL) return hit.value as T;
  const value = await load();
  memory.set(key, { at: Date.now(), value });
  return value;
}

export type HomePayload = {
  hero: AnimeCard | null;
  trending: AnimeCard[];
  seasonal: AnimeCard[];
  seasonName: string;
  popular: AnimeCard[];
  warning: string | null;
};

export const getHome = createServerFn({ method: "GET" }).handler(async (): Promise<HomePayload> => {
  const { season, year } = currentSeason();
  try {
    const data = await cached(`home:${season}:${year}`, () =>
      gql<{
        trending: { media: RawMedia[] };
        seasonal: { media: RawMedia[] };
        popular: { media: RawMedia[] };
      }>(
        `query ($season: MediaSeason, $year: Int) {
          trending: Page(page: 1, perPage: 16) {
            media(type: ANIME, sort: TRENDING_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
          seasonal: Page(page: 1, perPage: 16) {
            media(type: ANIME, season: $season, seasonYear: $year, sort: POPULARITY_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
          popular: Page(page: 1, perPage: 16) {
            media(type: ANIME, sort: POPULARITY_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
        }`,
        { season, year },
      ),
    );
    const trending = data.trending.media.map((item) => mapCard(item));
    const seasonal = data.seasonal.media.map((item) => mapCard(item));
    const popular = data.popular.media.map((item) => mapCard(item));
    const hero = trending.find((item) => item.banner && item.synopsis) ?? trending[0] ?? null;
    return {
      hero,
      trending,
      seasonal,
      seasonName: seasonLabel(season, year) ?? "This season",
      popular,
      warning: null,
    };
  } catch (error) {
    return {
      hero: null,
      trending: [],
      seasonal: [],
      seasonName: seasonLabel(season, year) ?? "This season",
      popular: [],
      warning: error instanceof Error ? error.message : "Catalog is unavailable.",
    };
  }
});

export const getAnime = createServerFn({ method: "GET" })
  .validator((input: { id: number }) => {
    const id = Number(input?.id);
    if (!Number.isFinite(id) || id <= 0) throw new Error("That title is missing.");
    return { id };
  })
  .handler(async ({ data }): Promise<AnimeDetail | null> => {
    try {
      return await cached(`anime:${data.id}`, async () => {
        const result = await gql<{
          Media: (RawMedia & {
            relations?: {
              edges?: {
                relationType?: string | null;
                node?: RawMedia | null;
              }[] | null;
            } | null;
          }) | null;
        }>(
          `query ($id: Int) {
            Media(id: $id, type: ANIME, isAdult: false) {
              ${CARD_FIELDS}
              relations {
                edges {
                  relationType
                  node { id title { romaji english } coverImage { large } format type }
                }
              }
            }
          }`,
          { id: data.id },
        );
        if (!result.Media) return null;
        const card = mapCard(result.Media, 900);
        const related: RelatedCard[] = (result.Media.relations?.edges ?? [])
          .filter((edge) => edge.node && (edge.node as { type?: string }).type !== "MANGA")
          .slice(0, 12)
          .map((edge) => {
            const node = edge.node as RawMedia;
            const romaji = node.title?.romaji?.trim() || "Untitled";
            return {
              id: node.id,
              title: node.title?.english?.trim() || romaji,
              cover: node.coverImage?.large || node.coverImage?.extraLarge || null,
              formatLabel: formatLabel(node.format),
              relation: (edge.relationType ?? "Related").replaceAll("_", " ").toLowerCase(),
            };
          });
        return { ...card, related };
      });
    } catch {
      return null;
    }
  });

export type BrowsePayload = {
  items: AnimeCard[];
  page: number;
  hasNext: boolean;
  warning: string | null;
};

const SORTS = new Set(["TRENDING_DESC", "POPULARITY_DESC", "SCORE_DESC", "START_DATE_DESC"]);
const FORMATS = new Set(["", "TV", "MOVIE", "OVA", "ONA", "SPECIAL"]);

export const browseAnime = createServerFn({ method: "GET" })
  .validator((input: BrowseSearch) => {
    const page = Math.min(20, Math.max(1, Number(input?.page) || 1));
    const sort = SORTS.has(input?.sort) ? input.sort : "TRENDING_DESC";
    const format = FORMATS.has(input?.format) ? input.format : "";
    const genre = typeof input?.genre === "string" ? input.genre.slice(0, 40) : "";
    return { genre, format, sort, page };
  })
  .handler(async ({ data }): Promise<BrowsePayload> => {
    try {
      const payload = await cached(`browse:${JSON.stringify(data)}`, () =>
        gql<{ Page: { pageInfo: { hasNextPage: boolean }; media: RawMedia[] } }>(
          `query ($page: Int, $sort: [MediaSort], $genre: String, $format: MediaFormat) {
            Page(page: $page, perPage: 24) {
              pageInfo { hasNextPage }
              media(type: ANIME, sort: $sort, genre: $genre, format: $format, isAdult: false) { ${CARD_FIELDS} }
            }
          }`,
          {
            page: data.page,
            sort: [data.sort],
            genre: data.genre || undefined,
            format: data.format || undefined,
          },
        ),
      );
      return {
        items: payload.Page.media.map((item) => mapCard(item, 140)),
        page: data.page,
        hasNext: payload.Page.pageInfo.hasNextPage,
        warning: null,
      };
    } catch (error) {
      return {
        items: [],
        page: data.page,
        hasNext: false,
        warning: error instanceof Error ? error.message : "Catalog is unavailable.",
      };
    }
  });

export const searchAnime = createServerFn({ method: "GET" })
  .validator((input: { query: string }) => {
    const query = (input?.query ?? "").trim().slice(0, 80);
    return { query };
  })
  .handler(async ({ data }): Promise<AnimeCard[]> => {
    if (data.query.length < 2) return [];
    try {
      const payload = await cached(`search:${data.query.toLowerCase()}`, () =>
        gql<{ Page: { media: RawMedia[] } }>(
          `query ($search: String) {
            Page(page: 1, perPage: 8) {
              media(type: ANIME, search: $search, sort: SEARCH_MATCH, isAdult: false) { ${CARD_FIELDS} }
            }
          }`,
          { search: data.query },
        ),
      );
      return payload.Page.media.map((item) => mapCard(item, 120));
    } catch {
      return [];
    }
  });

export type ScheduleEntry = AnimeCard & { airingAt: number; episode: number };

export const getSchedule = createServerFn({ method: "GET" }).handler(async (): Promise<{
  items: ScheduleEntry[];
  warning: string | null;
}> => {
  try {
    const payload = await cached("schedule", () =>
      gql<{ Page: { media: RawMedia[] } }>(
        `query {
          Page(page: 1, perPage: 40) {
            media(type: ANIME, status: RELEASING, sort: POPULARITY_DESC, isAdult: false) { ${CARD_FIELDS} }
          }
        }`,
        {},
      ),
    );
    const items = payload.Page.media
      .map((item) => mapCard(item, 80))
      .filter((item): item is AnimeCard & { nextEpisode: { episode: number; airingAt: number } } =>
        Boolean(item.nextEpisode),
      )
      .map((item) => ({
        ...item,
        airingAt: item.nextEpisode.airingAt,
        episode: item.nextEpisode.episode,
      }))
      .sort((a, b) => a.airingAt - b.airingAt);
    return { items, warning: null };
  } catch (error) {
    return {
      items: [],
      warning: error instanceof Error ? error.message : "Schedule is unavailable.",
    };
  }
});
