const DB_NAME = "daltron-aniverse";
const STORE = "files";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open the local shelf."));
  });
}

function run<T>(mode: IDBTransactionMode, work: (store: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  return openDb().then(
    (db) =>
      new Promise<T>((resolve, reject) => {
        const tx = db.transaction(STORE, mode);
        const request = work(tx.objectStore(STORE));
        request.onsuccess = () => {
          resolve(request.result);
          db.close();
        };
        request.onerror = () => {
          reject(request.error ?? new Error("Local shelf failed."));
          db.close();
        };
      }),
  );
}

export function idbPut(key: string, blob: Blob): Promise<void> {
  return run("readwrite", (store) => store.put(blob, key)).then(() => undefined);
}

export function idbGet(key: string): Promise<Blob | null> {
  return run<Blob | undefined>("readonly", (store) => store.get(key)).then((value) => value ?? null);
}

export function idbDel(key: string): Promise<void> {
  return run("readwrite", (store) => store.delete(key)).then(() => undefined);
}
