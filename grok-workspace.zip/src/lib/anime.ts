export type AnimeCard = {
  id: number;
  title: string;
  romaji: string;
  native: string | null;
  synopsis: string;
  cover: string | null;
  banner: string | null;
  episodes: number | null;
  duration: number | null;
  status: string;
  statusLabel: string;
  seasonLabel: string | null;
  format: string;
  formatLabel: string;
  score: number | null;
  genres: string[];
  studios: string[];
  trailerId: string | null;
  nextEpisode: { episode: number; airingAt: number } | null;
};

export type RelatedCard = {
  id: number;
  title: string;
  cover: string | null;
  formatLabel: string;
  relation: string;
};

export type AnimeDetail = AnimeCard & {
  related: RelatedCard[];
};

export type BrowseSearch = {
  genre: string;
  format: string;
  sort: string;
  page: number;
};

export const BROWSE_DEFAULT: BrowseSearch = {
  genre: "",
  format: "",
  sort: "TRENDING_DESC",
  page: 1,
};

export const GENRES = [
  "Action",
  "Adventure",
  "Comedy",
  "Drama",
  "Fantasy",
  "Horror",
  "Mystery",
  "Romance",
  "Sci-Fi",
  "Slice of Life",
  "Sports",
  "Supernatural",
  "Thriller",
] as const;

export const FORMATS = [
  { id: "TV", label: "Series" },
  { id: "MOVIE", label: "Movies" },
  { id: "OVA", label: "OVA" },
  { id: "ONA", label: "ONA" },
  { id: "SPECIAL", label: "Specials" },
] as const;

export const SORTS = [
  { id: "TRENDING_DESC", label: "Trending" },
  { id: "POPULARITY_DESC", label: "Popular" },
  { id: "SCORE_DESC", label: "Top rated" },
  { id: "START_DATE_DESC", label: "Newest" },
] as const;

const FORMAT_LABELS: Record<string, string> = {
  TV: "Series",
  TV_SHORT: "Short",
  MOVIE: "Movie",
  SPECIAL: "Special",
  OVA: "OVA",
  ONA: "ONA",
  MUSIC: "Music",
};

const STATUS_LABELS: Record<string, string> = {
  FINISHED: "Completed",
  RELEASING: "Airing",
  NOT_YET_RELEASED: "Upcoming",
  CANCELLED: "Cancelled",
  HIATUS: "Hiatus",
};

export function formatLabel(format: string | null | undefined): string {
  if (!format) return "Anime";
  return FORMAT_LABELS[format] ?? format;
}

export function statusLabel(status: string | null | undefined): string {
  if (!status) return "Unknown";
  return STATUS_LABELS[status] ?? status;
}

export function seasonLabel(season: string | null | undefined, year: number | null | undefined): string | null {
  if (!season && !year) return null;
  const name = season ? season.charAt(0) + season.slice(1).toLowerCase() : "Season";
  return year ? `${name} ${year}` : name;
}

export function scoreText(score: number | null): string | null {
  if (score == null) return null;
  return (score / 10).toFixed(1);
}

export function metaLine(anime: AnimeCard): string {
  const bits = [
    anime.formatLabel,
    anime.seasonLabel,
    anime.episodes ? `${anime.episodes} eps` : null,
    anime.duration ? `${anime.duration} min` : null,
    anime.statusLabel,
  ];
  return bits.filter(Boolean).join("  ·  ");
}

export function currentSeason(date = new Date()): { season: "WINTER" | "SPRING" | "SUMMER" | "FALL"; year: number } {
  const month = date.getUTCMonth();
  const year = date.getUTCFullYear();
  if (month <= 2) return { season: "WINTER", year };
  if (month <= 5) return { season: "SPRING", year };
  if (month <= 8) return { season: "SUMMER", year };
  return { season: "FALL", year };
}

export function clock(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return "0:00";
  const total = Math.floor(seconds);
  const minutes = Math.floor(total / 60);
  const rest = total % 60;
  return `${minutes}:${rest.toString().padStart(2, "0")}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
