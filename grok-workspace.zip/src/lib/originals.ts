export type OriginalEpisode = {
  number: number;
  title: string;
  blurb: string;
  src: string;
  still: string;
  seconds: number;
};

export type OriginalSeries = {
  slug: string;
  title: string;
  logline: string;
  poster: string;
  banner: string;
  year: number;
  genres: string[];
  episodes: OriginalEpisode[];
};

export const lanternRun: OriginalSeries = {
  slug: "lantern-run",
  title: "Lantern Run",
  logline:
    "An original motion reel made for Daltron. A courier, a paper lantern, and a city that does not exist anywhere else. Stream it here or save the file.",
  poster: "/originals/poster.jpg",
  banner: "/originals/banner.jpg",
  year: 2026,
  genres: ["Original", "Action", "Night"],
  episodes: [
    {
      number: 1,
      title: "Rooftop Relay",
      blurb: "A courier crosses the roofs with one light and a long red scarf.",
      src: "/originals/ep1.mp4",
      still: "/originals/ep1.jpg",
      seconds: 15,
    },
    {
      number: 2,
      title: "Paper Bridge",
      blurb: "Two lanterns stop over black water.",
      src: "/originals/ep2.mp4",
      still: "/originals/ep2.jpg",
      seconds: 15,
    },
    {
      number: 3,
      title: "Crane Market",
      blurb: "A paper crane folded out of metal sweeps the night market.",
      src: "/originals/ep3.mp4",
      still: "/originals/ep3.jpg",
      seconds: 15,
    },
  ],
};

export function findOriginal(slug: string): OriginalSeries | null {
  return slug === lanternRun.slug ? lanternRun : null;
}
