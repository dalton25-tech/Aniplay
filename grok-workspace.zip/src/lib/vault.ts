import { useEffect, useState } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ProgressEntry = {
  key: string;
  title: string;
  subtitle: string;
  poster: string | null;
  href: string;
  seconds: number;
  duration: number;
  updated: number;
};

export type ShelfEpisode = {
  id: string;
  number: number;
  title: string;
  fileName: string;
  mime: string;
  bytes: number;
};

export type Shelf = {
  id: string;
  title: string;
  cover: string | null;
  anilistId: number | null;
  episodes: ShelfEpisode[];
};

export type ListEntry = {
  id: number;
  title: string;
  cover: string | null;
};

type VaultState = {
  watchlist: ListEntry[];
  progress: Record<string, ProgressEntry>;
  shelves: Shelf[];
  toggleList: (entry: ListEntry) => void;
  setProgress: (entry: ProgressEntry) => void;
  saveShelf: (shelf: Shelf) => void;
  removeShelf: (id: string) => void;
};

export const useVault = create<VaultState>()(
  persist(
    (set, get) => ({
      watchlist: [],
      progress: {},
      shelves: [],
      toggleList: (entry) => {
        const has = get().watchlist.some((item) => item.id === entry.id);
        set({
          watchlist: has
            ? get().watchlist.filter((item) => item.id !== entry.id)
            : [entry, ...get().watchlist],
        });
      },
      setProgress: (entry) =>
        set({
          progress: { ...get().progress, [entry.key]: entry },
        }),
      saveShelf: (shelf) => {
        const shelves = get().shelves;
        const index = shelves.findIndex((item) => item.id === shelf.id);
        if (index === -1) {
          set({ shelves: [shelf, ...shelves] });
          return;
        }
        const next = shelves.slice();
        next[index] = shelf;
        set({ shelves: next });
      },
      removeShelf: (id) =>
        set({
          shelves: get().shelves.filter((item) => item.id !== id),
          progress: Object.fromEntries(
            Object.entries(get().progress).filter(([, entry]) => !entry.href.includes(`/watch/shelf/${id}`)),
          ),
        }),
    }),
    { name: "daltron-aniverse", skipHydration: true },
  ),
);

export function useVaultReady(): boolean {
  const [ready, setReady] = useState(false);
  useEffect(() => {
    void useVault.persist.rehydrate();
    const unsub = useVault.persist.onFinishHydration(() => setReady(true));
    if (useVault.persist.hasHydrated()) setReady(true);
    return unsub;
  }, []);
  return ready;
}
