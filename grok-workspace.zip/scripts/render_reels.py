#!/usr/bin/env python3
"""Render original Daltron title reels and posters. Geometric motion graphics, no third-party footage."""

from __future__ import annotations

import math
import os
import random
import subprocess

from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1280, 720
FPS = 12
SECONDS = 15
FRAMES = FPS * SECONDS
OUT = "/workspace/public/originals"
FONT_DIR = "/usr/share/fonts/truetype/liberation"
SERIF = os.path.join(FONT_DIR, "LiberationSerif-Italic.ttf")
SERIF_REG = os.path.join(FONT_DIR, "LiberationSerif-Bold.ttf")
SANS = os.path.join(FONT_DIR, "LiberationSans-Bold.ttf")
SANS_REG = os.path.join(FONT_DIR, "LiberationSans-Regular.ttf")

random.seed(7)


def font(path: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(path, size)


def vertical_gradient(top: tuple[int, int, int], bottom: tuple[int, int, int]) -> Image.Image:
    img = Image.new("RGB", (W, H))
    px = img.load()
    for y in range(H):
        t = y / (H - 1)
        color = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        for x in range(W):
            px[x, y] = color
    return img


def glow_sprite(diameter: int, color: tuple[int, int, int]) -> Image.Image:
    sprite = Image.new("RGBA", (diameter, diameter), (0, 0, 0, 0))
    px = sprite.load()
    c = diameter / 2
    for y in range(diameter):
        for x in range(diameter):
            d = math.hypot(x - c, y - c) / c
            if d >= 1:
                continue
            a = int(255 * (1 - d) ** 2.2)
            px[x, y] = (color[0], color[1], color[2], a)
    return sprite


def paste(base: Image.Image, sprite: Image.Image, xy: tuple[int, int]) -> None:
    base.alpha_composite(sprite, xy)


def text_size(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.FreeTypeFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[2] - box[0], box[3] - box[1]


def draw_centered(
    draw: ImageDraw.ImageDraw,
    text: str,
    y: int,
    fnt: ImageFont.FreeTypeFont,
    fill: tuple[int, int, int, int],
) -> None:
    tw, _ = text_size(draw, text, fnt)
    draw.text(((W - tw) / 2, y), text, font=fnt, fill=fill)


def rooftops(draw: ImageDraw.ImageDraw, shift: float, tint: tuple[int, int, int]) -> None:
    ground = 470
    x = -80 + shift
    i = 0
    while x < W + 40:
        width = 90 + (i * 37) % 80
        height = 70 + (i * 53) % 150
        top = ground - height
        draw.polygon(
            [(x, H), (x, top + 16), (x + 18, top), (x + width, top + 8), (x + width, H)],
            fill=(*tint, 255),
        )
        # a few lit windows
        wx = x + 16
        while wx < x + width - 18:
            wy = top + 28
            while wy < ground - 10:
                if ((i * 13 + int(wx) + int(wy)) % 7) == 0:
                    lit = (255, 186, 120, 180) if (i + int(wy)) % 2 == 0 else (255, 90, 60, 140)
                    draw.rectangle((wx, wy, wx + 8, wy + 12), fill=lit)
                wy += 26
            wx += 22
        x += width - 6
        i += 1


def rain(draw: ImageDraw.ImageDraw, frame: int, density: int = 90) -> None:
    for i in range(density):
        x = (i * 97 + frame * (6 + (i % 5))) % (W + 40) - 20
        y = (i * 53 + frame * (14 + (i % 7))) % (H + 30) - 20
        draw.line((x, y, x - 6, y + 16), fill=(244, 239, 230, 70), width=1)


def scarf(draw: ImageDraw.ImageDraw, x: float, y: float, frame: int, color: tuple[int, int, int]) -> None:
    for i in range(16):
        t = i / 16
        sx = x - 18 - i * 14
        sy = y + 8 + math.sin(frame / 3.5 + i * 0.55) * (8 + i * 0.4)
        r = max(2, 11 - i * 0.45)
        alpha = int(210 * (1 - t))
        draw.ellipse((sx - r, sy - r, sx + r, sy + r), fill=(*color, alpha))


def lantern(base: Image.Image, glow: Image.Image, x: float, y: float) -> None:
    paste(base, glow, (int(x - glow.width / 2), int(y - glow.height / 2)))
    overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    d.ellipse((x - 16, y - 20, x + 16, y + 22), fill=(255, 120, 48, 255))
    d.ellipse((x - 8, y - 10, x + 8, y + 12), fill=(255, 236, 210, 255))
    d.rectangle((x - 2, y - 28, x + 2, y - 18), fill=(244, 239, 230, 220))
    base.alpha_composite(overlay)


def crane(draw: ImageDraw.ImageDraw, x: float, y: float, scale: float, alpha: int) -> None:
    col = (244, 239, 230, alpha)
    pts = [
        (0, 0),
        (18, -6),
        (46, -2),
        (70, 8),
        (46, 4),
        (20, 10),
        (8, 28),
        (0, 10),
        (-28, 18),
        (-8, 4),
    ]
    poly = [(x + px * scale, y + py * scale) for px, py in pts]
    draw.line(poly + [poly[0]], fill=col, width=3)


def fade(frame: int, start: int, end: int) -> float:
    if frame < start or frame > end:
        return 0.0
    inn = min(1.0, (frame - start) / 8)
    out = min(1.0, (end - frame) / 8)
    return max(0.0, min(inn, out))


def render_episode(index: int, title: str, kicker: str) -> None:
    folder = os.path.join(OUT, f"frames-{index}")
    os.makedirs(folder, exist_ok=True)
    sky = vertical_gradient((18, 10, 14), (9, 10, 12))
    vignette = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    vd = ImageDraw.Draw(vignette)
    vd.rectangle((0, 0, W, 90), fill=(0, 0, 0, 90))
    vd.rectangle((0, H - 160, W, H), fill=(0, 0, 0, 150))
    glow = glow_sprite(220, (255, 70, 32))
    f_kicker = font(SANS, 22)
    f_title = font(SERIF, 86)
    f_small = font(SANS_REG, 20)
    f_brand = font(SERIF_REG, 28)

    for frame in range(FRAMES):
        img = sky.copy().convert("RGBA")
        overlay = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        shift = -((frame * 3 + index * 40) % 180)
        rooftops(draw, shift, (16, 14, 18) if index != 2 else (22, 12, 14))
        rain(draw, frame, 70 if index != 3 else 120)

        t = frame / FRAMES
        if index == 1:
            lx = 160 + t * 980
            ly = 360 + math.sin(frame / 5) * 16
            scarf(draw, lx, ly, frame, (255, 59, 31))
            img.alpha_composite(overlay)
            lantern(img, glow, lx, ly)
        elif index == 2:
            a = 280 + t * 260
            b = 1000 - t * 260
            ya = 390 + math.sin(frame / 6) * 12
            yb = 400 + math.cos(frame / 6) * 12
            scarf(draw, a, ya, frame, (255, 59, 31))
            scarf(draw, b, yb, frame + 4, (244, 220, 190))
            # bridge
            draw.polygon([(0, 520), (W, 500), (W, 560), (0, 580)], fill=(28, 24, 26, 255))
            img.alpha_composite(overlay)
            lantern(img, glow, a, ya - 28)
            lantern(img, glow, b, yb - 28)
        else:
            lx = 220 + t * 860
            ly = 430 + math.sin(frame / 3) * 8
            scarf(draw, lx, ly, frame, (255, 59, 31))
            crane(draw, 200 + frame * 8, 160 + math.sin(frame / 4) * 20, 2.4, 150)
            img.alpha_composite(overlay)
            lantern(img, glow, lx, ly - 36)

        titles = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        td = ImageDraw.Draw(titles)
        a1 = fade(frame, 4, 36)
        a2 = fade(frame, 40, 110)
        a3 = fade(frame, 116, FRAMES - 2)
        if a1:
            draw_centered(td, "DALTRON  ORIGINALS", 250, f_kicker, (244, 239, 230, int(255 * a1)))
            draw_centered(td, "LANTERN RUN", 300, f_title, (244, 239, 230, int(255 * a1)))
        if a2:
            draw_centered(td, f"EPISODE  0{index}", 250, f_kicker, (255, 59, 31, int(255 * a2)))
            draw_centered(td, title.upper(), 300, f_title, (244, 239, 230, int(255 * a2)))
        if a3:
            draw_centered(td, kicker, 560, f_small, (156, 150, 140, int(255 * a3)))
        draw_centered(td, "DALTRON ANIVERSE", 40, f_brand, (244, 239, 230, 210))
        img.alpha_composite(titles)
        img.alpha_composite(vignette)
        img.convert("RGB").save(os.path.join(folder, f"{frame:04d}.png"), quality=95)
        if frame == 70:
            still = img.convert("RGB").filter(ImageFilter.SMOOTH)
            still.save(os.path.join(OUT, f"ep{index}.jpg"), quality=90)

    mp4 = os.path.join(OUT, f"ep{index}.mp4")
    subprocess.check_call(
        [
            "ffmpeg",
            "-y",
            "-framerate",
            str(FPS),
            "-i",
            os.path.join(folder, "%04d.png"),
            "-f",
            "lavfi",
            "-i",
            f"sine=frequency={90 + index * 12}:duration={SECONDS}",
            "-f",
            "lavfi",
            "-i",
            f"anoisesrc=color=pink:amplitude=0.012:duration={SECONDS}",
            "-filter_complex",
            "[1:a]volume=0.03[a1];[2:a]volume=0.6[a2];[a1][a2]amix=inputs=2:duration=longest[a]",
            "-map",
            "0:v",
            "-map",
            "[a]",
            "-c:v",
            "libx264",
            "-pix_fmt",
            "yuv420p",
            "-preset",
            "veryfast",
            "-crf",
            "22",
            "-c:a",
            "aac",
            "-b:a",
            "96k",
            "-shortest",
            mp4,
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    # frames are only build scratch
    for name in os.listdir(folder):
        os.remove(os.path.join(folder, name))
    os.rmdir(folder)


def poster() -> None:
    pw, ph = 800, 1200
    img = Image.new("RGB", (pw, ph))
    px = img.load()
    for y in range(ph):
        t = y / (ph - 1)
        color = (int(28 + (9 - 28) * t), int(12 + (10 - 12) * t), int(14 + (12 - 14) * t))
        for x in range(pw):
            px[x, y] = color
    img = img.convert("RGBA")
    glow = glow_sprite(460, (255, 59, 31))
    img.alpha_composite(glow, (170, 360))
    d = ImageDraw.Draw(img)
    d.ellipse((330, 640, 470, 800), fill=(255, 120, 48, 255))
    d.ellipse((370, 680, 430, 750), fill=(255, 236, 210, 255))
    for i in range(12):
        x = 300 - i * 16
        y = 730 + math.sin(i) * 14
        r = 14 - i * 0.5
        d.ellipse((x, y, x + r * 2, y + r), fill=(255, 59, 31, int(200 - i * 12)))
    f_small = font(SANS, 28)
    f_big = font(SERIF, 92)
    f_sub = font(SANS_REG, 22)

    def center(text: str, y: int, fnt: ImageFont.FreeTypeFont, fill: tuple[int, int, int, int]) -> None:
        box = d.textbbox((0, 0), text, font=fnt)
        tw = box[2] - box[0]
        d.text(((pw - tw) / 2, y), text, font=fnt, fill=fill)

    center("DALTRON ORIGINAL", 160, f_small, (255, 59, 31, 255))
    center("Lantern", 250, f_big, (244, 239, 230, 255))
    center("Run", 360, f_big, (244, 239, 230, 255))
    center("THREE REELS  ·  STREAM OR SAVE", 1040, f_sub, (156, 150, 140, 255))
    img.convert("RGB").save(os.path.join(OUT, "poster.jpg"), quality=90)


def banner() -> None:
    img = vertical_gradient((20, 10, 12), (9, 10, 12)).resize((1600, 900), Image.Resampling.LANCZOS)
    # rebuild at banner size
    img = vertical_gradient((22, 10, 14), (9, 10, 12)).resize((1600, 900))
    img = img.convert("RGBA")
    glow = glow_sprite(640, (255, 70, 36))
    paste(img, glow, (980, 180))
    d = ImageDraw.Draw(img)
    for i in range(8):
        x = 80 + i * 190
        h = 180 + (i % 3) * 70
        d.polygon(
            [(x, 900), (x + 20, 900 - h), (x + 150, 900 - h + 20), (x + 170, 900)],
            fill=(14, 13, 16, 255),
        )
    f_big = font(SERIF, 120)
    f_small = font(SANS, 32)
    d.text((90, 250), "Lantern Run", font=f_big, fill=(244, 239, 230, 255))
    d.text((96, 400), "AN ORIGINAL REEL  ·  PLAY IT HERE", font=f_small, fill=(255, 59, 31, 255))
    img.convert("RGB").save(os.path.join(OUT, "banner.jpg"), quality=90)


def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    poster()
    banner()
    episodes = [
        (1, "Rooftop Relay", "A courier. A lantern. A city with no name."),
        (2, "Paper Bridge", "Two lights meet over black water."),
        (3, "Crane Market", "Something folded out of the dark gives chase."),
    ]
    for index, title, kicker in episodes:
        print(f"rendering {title}", flush=True)
        render_episode(index, title, kicker)
    print("done", flush=True)


if __name__ == "__main__":
    main()
